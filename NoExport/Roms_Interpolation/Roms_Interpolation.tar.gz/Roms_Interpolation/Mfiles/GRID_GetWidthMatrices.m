function [WidthU, WidthV]=GRID_GetWidthMatrices(LON_psi2, LAT_psi2)
[eta_psi2, xi_psi2]=size(LON_psi2);
eta_u=eta_psi2-1;
xi_u=xi_psi2-2;
eta_v=eta_psi2-2;
xi_v=xi_psi2-1;

WidthU=zeros(eta_u, xi_u);
for iEta=1:eta_u
  for iXi=1:xi_u
    LonDeg1=LON_psi2(iEta, iXi+1);
    LatDeg1=LAT_psi2(iEta, iXi+1);
    LonDeg2=LON_psi2(iEta+1, iXi+1);
    LatDeg2=LAT_psi2(iEta+1, iXi+1);
    dist=GeodesicDistance_V2(LonDeg1, LatDeg1, LonDeg2, LatDeg2);
    WidthU(iEta, iXi)=dist;
  end;
end;

WidthV=zeros(eta_v, xi_v);
for iEta=1:eta_v
  for iXi=1:xi_v
    LonDeg1=LON_psi2(iEta+1, iXi);
    LatDeg1=LAT_psi2(iEta+1, iXi);
    LonDeg2=LON_psi2(iEta+1, iXi+1);
    LatDeg2=LAT_psi2(iEta+1, iXi+1);
    dist=GeodesicDistance_V2(LonDeg1, LatDeg1, LonDeg2, LatDeg2);
    WidthV(iEta, iXi)=dist;
  end;
end;
