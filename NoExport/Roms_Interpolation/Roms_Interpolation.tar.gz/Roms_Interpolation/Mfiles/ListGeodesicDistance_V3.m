function ListDist=ListGeodesicDistance_V3(...
    ListLon1, ListLat1, eLon, eLat)
eLonRad2=eLon*(pi/180);
eLatRad2=eLat*(pi/180);
x2=cos(eLonRad2)*cos(eLatRad2);
y2=sin(eLonRad2)*cos(eLatRad2);
z2=sin(eLatRad2);

ListLonRad1=ListLon1*(pi/180);
ListLatRad1=ListLat1*(pi/180);
x1=cos(ListLonRad1).*cos(ListLatRad1);
y1=sin(ListLonRad1).*cos(ListLatRad1);
z1=sin(ListLatRad1);

ListDist=acos(x1*x2 + y1*y2 + z1*z2);
