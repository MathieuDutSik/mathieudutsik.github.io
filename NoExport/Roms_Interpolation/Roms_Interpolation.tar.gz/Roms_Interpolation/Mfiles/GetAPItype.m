function TheAPI=GetAPItype()

ePath='/opt/matlab/netcdf/mexcdf/';
test=exist(ePath, 'dir');
if (test ~= 0)
  TheAPI='API2';
else
  TheAPI='API1';
end;