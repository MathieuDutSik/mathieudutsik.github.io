function [test, reason]=IsMakeableFile(TheFile)



res=SplitLine(TheFile, '/');
nbComp=size(res,2);
if (nbComp == 1)
  test=1;
  reason='all ok';
else
  eFirstChar=TheFile(1,1);
  if (eFirstChar == '/')
    str='/';
  else
    str='';
  end;
  len=nbComp-1;
  for i=1:len
    str=[str res{i} '/'];
  end;
  if (IsExistingFile(str) == 1)
    test=1;
    reason='all ok';
  else
    disp(['str=' str]);
    test=0;
    reason='directory non-existent';
  end;
end;
