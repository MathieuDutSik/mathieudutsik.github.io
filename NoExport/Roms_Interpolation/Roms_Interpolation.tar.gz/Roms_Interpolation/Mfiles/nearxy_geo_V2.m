function [TheIdx, TheDist]=nearxy_geo_V2(LON, LAT, eLon, eLat)

LONexp=LON(:);
LATexp=LAT(:);
nbPt=size(LONexp, 1);

TheMeth=3;
if (TheMeth == 2)
  ListDist=ListGeodesicDistance_V2(...
      LONexp, LATexp, eLon, eLat);
elseif (TheMeth == 3)
  ListDist=ListGeodesicDistance_V3(...
      LONexp, LATexp, eLon, eLat);
else
  disp('Please put your mind here');
  error('Please correct');
end;
minDist=min(ListDist);
K=find(ListDist == minDist);

TheIdx=K(1,1);
TheDist=minDist;
