function HistoryArray=ROMShistoryGetInfoMult5(...
    HisPrefix, BeginTimeDay, EndTimeDay)

Day2sec=24*3600;
BeginTimeSec=BeginTimeDay*Day2sec;
EndTimeSec=EndTimeDay*Day2sec;
HistoryArray=ROMShistoryGetInfoMult4(...
    HisPrefix, BeginTimeSec, EndTimeSec);
