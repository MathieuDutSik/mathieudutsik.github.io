function TotalArray=InterpolGetTotalArray_R2R_fields(...
    BigGridFile, SmallGridFile)
%
GrdArrBig=GRID_GetArraySimple(BigGridFile);
GrdArrSma=GRID_GetArraySimple(SmallGridFile);
%
TotalArray=InterpolGetTotalArray_R2R_fields_kernel(...
    GrdArrBig, GrdArrSma);
