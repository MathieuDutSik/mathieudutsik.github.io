function [ListETA, ListXI, ListCoeff]=...
    Interpol_R2R_GetCoefficients_V2(...
	LONbig_rho, LATbig_rho, ...
	LONsma_rho, LATsma_rho)

[eta_rho_big, xi_rho_big]=size(LONbig_rho);
[eta_rho_sma, xi_rho_sma]=size(LONsma_rho);
disp(['eta_rho_big=' num2str(eta_rho_big) ...
      '  xi_rho_big=' num2str(xi_rho_big)]);
disp(['eta_rho_sma=' num2str(eta_rho_sma) ...
      '  xi_rho_sma=' num2str(xi_rho_sma)]);
disp(['LONbig min=' num2str(min(LONbig_rho(:))) ...
      ' max=' num2str(max(LONbig_rho(:)))]);
disp(['LATbig min=' num2str(min(LATbig_rho(:))) ...
      ' max=' num2str(max(LATbig_rho(:)))]);
disp(['LONsma min=' num2str(min(LONsma_rho(:))) ...
      ' max=' num2str(max(LONsma_rho(:)))]);
disp(['LATsma min=' num2str(min(LATsma_rho(:))) ...
      ' max=' num2str(max(LATsma_rho(:)))]);


%disp('Before call to InterpolSquareGrid2SquareGrid');
TheRecordInterp=InterpolSquareGrid2SquareGrid(...
    LONsma_rho, LATsma_rho, ...
    LONbig_rho, LATbig_rho);
%disp(' After call to InterpolSquareGrid2SquareGrid');

ListGuessETA=TheRecordInterp.MAT_L(:);
ListGuessXI=TheRecordInterp.MAT_M(:);

ListLON=LONsma_rho(:);
ListLAT=LATsma_rho(:);

%disp('Before call to InterpolDetermineContainingCell');
[ListETAexp, ListXIexp, ListCoeffExp]=...
    InterpolDetermineContainingCell(...
	LONbig_rho, LATbig_rho, ...
	ListLON, ListLAT, ...
	ListGuessETA, ListGuessXI);
%disp(' After call to InterpolDetermineContainingCell');


ListETA=reshape(ListETAexp, eta_rho_sma, xi_rho_sma);
ListXI=reshape(ListXIexp,   eta_rho_sma, xi_rho_sma);
ListCoeff=zeros(eta_rho_sma, xi_rho_sma, 4);
for i=1:4
  H=ListCoeffExp(:, i);
  H2=reshape(H, eta_rho_sma, xi_rho_sma);
  ListCoeff(:, :, i)=H2;
end;
disp('End of Interpol_R2R_Get_Coefficients_V2');