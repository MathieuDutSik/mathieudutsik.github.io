function [ListTimeHistory, ListFile, ListIRecord, nbFile, ...
	  ListFileUniq, ListIFileUniq]=...
    ROMShistoryGetInfoMult2(HisPrefix, BeginTimeSec, EndTimeSec)
Day2sec=24*3600;
TheAPI=GetAPItype();
%
% It reads from an existing list of record
%
TheTolSec=10; % a tolerance of 10 second will not create any problem.
if (IsExistingFile(HisPrefix) == 1)
  % single history file, we read and finish
  if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
    nc=netcdf(HisPrefix, 'nowrite');
    LTime_read=nc{'ocean_time'}(:);
    eTimeStr=nc{'ocean_time'}.units(:);
    close(nc);
  else
    LTime_read=nc_varget(HisPrefix, 'ocean_time');
    eTimeStr=nc_attget(HisPrefix, 'ocean_time', 'units');
  end;
  eMultSec=DATE_GetCFtimeMult_ForSec(eTimeStr);
  eRefTime=DATE_ConvertRomsRefNetcdf(eTimeStr);
  LTime=LTime_read*eMultSec + eRefTime*Day2sec;
  nbFile=1;
  ListFileUniq{1}=HisPrefix;
  idx=0;
  ListTimeHistory=zeros(0,1);
  ListIRecord=zeros(0,1);
  ListIFileUniq=zeros(0,1);
  nbTime=size(LTime,1);
  for iTime=1:nbTime
    eTime=LTime(iTime,1);
    if (BeginTimeSec-TheTolSec <= eTime && ...
	eTime <= EndTimeSec+TheTolSec)
      nbTime=nbTime+1;
      idx=idx+1;
      ListTimeHistory(idx,1)=eTime;
      ListFile{idx}=HisPrefix;
      ListIRecord(idx,1)=iTime;
      ListIFileUniq(idx,1)=1;
    end;
  end;
  return;
end;
%
%
%
H=dir([HisPrefix '*.nc']);
K=SplitLine(HisPrefix, '/');
lenB=size(K,2);
HisPrefixRed=K{lenB};
ThePrePrefix='';
for i=1:lenB-1
  ThePrePrefix=[ThePrePrefix K{i} '/'];
end;
if (HisPrefix(1,1) == '/')
  ThePrePrefix=['/' ThePrePrefix];
end;


nbFileDir=size(H,1);
if (nbFileDir == 0)
  disp('We are sorry, but the directory with prefix');
  disp(['HisPrefix=' HisPrefix]);
  disp('has zero .nc files');
  disp('This is maybe not what you want');
  error('Please correct');
end;
ListTimeHistory=zeros(0,1);
%clear('ListFile');
ListIRecord=zeros(0, 1);
ListIFileUniq=zeros(0, 1);
for iFile=1:nbFileDir
  eName=H(iFile, 1).name;
  nbChar=size(eName, 2);
  if (iFile == 1)
    nbCharPrev=nbChar;
  else
    if (nbChar ~= nbCharPrev)
      disp('The number of characters is not consistent');
      disp('maybe you mixed several kinds of files');
      error('Please correct');
    end;
  end;
end;
nbCharPrefix=size(HisPrefixRed, 2);
nbCharROMS=nbCharPrefix+4+3;
nbCharDay=nbCharPrefix+8+2+3;
%disp(['nbChar=' num2str(nbChar) ' nbCharROMS=' num2str(nbCharROMS)]);
if (nbChar == nbCharROMS)
  iFileBegin=0;
  while(1)
    iFileBegin=iFileBegin+1;
    TheHisFile=[HisPrefix StringNumber(iFileBegin, 4) '.nc'];
    if (IsExistingFile(TheHisFile) == 1)
      break;
    end;
    if (iFileBegin == 9999)
      disp(['maybe you specified wrong HisPrefix']);
      disp([' there is no files ' HisPrefix '????.nc']);
      error('Please correct');
    end;
  end;
  iFileEnd=iFileBegin;
  while(1)
    TheHisFile=[HisPrefix StringNumber(iFileEnd+1, 4) '.nc'];
    if (IsExistingFile(TheHisFile) == 0)
      break;
    end;
    iFileEnd=iFileEnd+1;
  end;
%	'  iFileEnd=' num2str(iFileEnd)]);
  TheHisFile=[HisPrefix StringNumber(iFileBegin, 4) '.nc'];
  if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
    nc=netcdf(TheHisFile, 'nowrite');
    LTimeBegin_read=nc{'ocean_time'}(:);
    eTimeStr=nc{'ocean_time'}.units(:);
    close(nc);
  else
    LTimeBegin_read=nc_varget(TheHisFile, 'ocean_time');
    eTimeStr=nc_attget(TheHisFile, 'ocean_time', 'units');
  end;
  eRefTime=DATE_ConvertRomsRefNetcdf(eTimeStr);
  eMultSec=DATE_GetCFtimeMult_ForSec(eTimeStr);
  LTimeBegin=LTimeBegin_read*eMultSec + eRefTime*Day2sec;
  nbRecBegin=size(LTimeBegin,1);
  TheBeginTimeHis=LTimeBegin(1,1);
  if (nbRecBegin > 1)
    DeltaTimeSec=LTimeBegin(2,1)-LTimeBegin(1,1);
  else
    if (iFileEnd > iFileBegin)
      TheHisFile=[HisPrefix StringNumber(iFileBegin+1, 4) '.nc'];
      if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
	nc=netcdf(TheHisFile, 'nowrite');
	LTimeBP1_read=nc{'ocean_time'}(:);
	close(nc);
      else
	LTimeBP1_read=nc_varget(TheHisFile, 'ocean_time');
      end;
      LTimeBP1=LTimeBP1_read*eMultSec + eRefTime*Day2sec;
      DeltaTimeSec=LTimeBP1(1,1) - LTimeBegin(1,1);
    else
      DeltaTimeSec=0;
    end;
  end;
%  disp(['DeltaTimeSec=' num2str(DeltaTimeSec)]);
  if (iFileEnd ~= iFileBegin)
    iFileMiddle=iFileBegin+1;
    TheHisFile=[HisPrefix StringNumber(iFileMiddle, 4) '.nc'];
    if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
      nc=netcdf(TheHisFile, 'nowrite');
      LTimeMiddle_read=nc{'ocean_time'}(:);
      close(nc);
    else
      LTimeMiddle_read=nc_varget(TheHisFile, 'ocean_time');
    end;
    LTimeMiddle=LTimeMiddle_read*eMultSec + eRefTime*Day2sec;
    nbRecMiddle=size(LTimeMiddle, 1);
  else
    iFileMiddle=iFileBegin;
    nbRecMiddle=nbRecBegin;
  end;
  if (iFileEnd ~= iFileMiddle)
    TheHisFile=[HisPrefix StringNumber(iFileEnd, 4) '.nc'];
    if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
      nc=netcdf(TheHisFile, 'nowrite');
      LTimeEnd_read=nc{'ocean_time'}(:);
      close(nc);
    else
      LTimeEnd_read=nc_varget(TheHisFile, 'ocean_time');
    end;
    LTimeEnd=LTimeEnd_read*eMultSec + eRefTime*Day2sec;
    nbRecEnd=size(LTimeEnd, 1);
  else
    nbRecEnd=nbRecMiddle;
  end;
  NbPerArray=zeros(iFileEnd,1);
  for iFile=iFileBegin:iFileEnd
    NbPerArray(iFile, 1)=nbRecMiddle;
  end;
  NbPerArray(iFileBegin,1)=nbRecBegin;
  NbPerArray(iFileEnd,1)=nbRecEnd;
%  disp(['nbRecBegin=' num2str(nbRecBegin) ...
%	'  nbRecEnd=' num2str(nbRecEnd)]);
%  disp(['iFileBegin=' num2str(iFileBegin)]);
  %
  currentTimeSec=LTimeBegin(1,1);
  TheFirstTime=currentTimeSec;
  idx=0;
  idxFile=0;
  for iFile=iFileBegin:iFileEnd
    TheHisFile=[HisPrefix StringNumber(iFile, 4) '.nc'];
    idxFile=idxFile+1;
    ListFileUniq{idxFile}=TheHisFile;
    nbRecord=NbPerArray(iFile,1);
    for iRecord=1:nbRecord
      if (currentTimeSec >= BeginTimeSec-TheTolSec && ...
	  currentTimeSec <= EndTimeSec+TheTolSec)
	idx=idx+1;
	ListFile{idx}=TheHisFile;
	ListIRecord(idx,1)=iRecord;
	ListIFileUniq(idx,1)=idxFile;
	ListTimeHistory(idx,1)=currentTimeSec;
	currentTimeDay=currentTimeSec/Day2sec;
	strPres=DATE_ConvertMjd2mystringPres(currentTimeDay);
      end;
      currentTimeSec=currentTimeSec+DeltaTimeSec;
    end;
  end;
  TheLastTime=currentTimeSec;
  if (idx == 0)
    strFirstTime=DATE_ConvertMjd2mystringPres(...
	TheFirstTime/Day2sec);
    strLastTime=DATE_ConvertMjd2mystringPres(...
	TheLastTime/Day2sec);
    strAskedBegin=DATE_ConvertMjd2mystringPres(...
	BeginTimeSec/Day2sec);
    strAskedEnd=DATE_ConvertMjd2mystringPres(...
	EndTimeSec/Day2sec);
    disp('We did not find any record matching');
    disp('the asked time frame.');
    disp(['HisPrefix=' HisPrefix]);
    disp(['Begining existing TimeFrame=' strFirstTime]);
    disp(['  Ending existing TimeFrame=' strLastTime]);
    disp(['   asked begining TimeFrame=' strAskedBegin]);
    disp(['     asked ending TimeFrame=' strAskedEnd]);
    disp('This is probably not what you want');
    error('Please correct');
  end;
  nbFile=1+iFileEnd-iFileBegin;
%  disp('return 2');
elseif (nbChar == nbCharDay)
  iFile1=1;
  iFile2=2;
  eFile1=[ThePrePrefix H(iFile1, 1).name];
  eFile2=[ThePrePrefix H(iFile2, 1).name];
  eFileLast=[ThePrePrefix H(nbFileDir, 1).name];
  %
  if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
    nc=netcdf(eFile1, 'nowrite');
    LTime1_read=nc{'ocean_time'}(:);
    eTimeStr=nc{'ocean_time'}.units(:);
    close(nc);
  else
    LTime1_read=nc_varget(eFile1, 'ocean_time');
    eTimeStr=nc_attget(eFile1, 'ocean_time', 'units');
  end;
  eRefTime=DATE_ConvertRomsRefNetcdf(eTimeStr);
  eMultSec=DATE_GetCFtimeMult_ForSec(eTimeStr);
  LTime1=LTime1_read*eMultSec + eRefTime*Day2sec;
  %
  if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
    nc=netcdf(eFile2, 'nowrite');
    LTime2_read=nc{'ocean_time'}(:);
    close(nc);
  else
    LTime2_read=nc_varget(eFile2, 'ocean_time');
  end;
  LTime2=LTime2_read*eMultSec + eRefTime*Day2sec;
  %
  if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
    nc=netcdf(eFileLast, 'nowrite');
    LTimeLast_read=nc{'ocean_time'}(:);
    close(nc);
  else
    LTimeLast_read=nc_varget(eFileLast, 'ocean_time');
  end;
  LTimeLast=LTimeLast_read*eMultSec + eRefTime*Day2sec;
  %
  nbTime1=size(LTime1,1);
  nbTime2=size(LTime2,1);
  nbTimeLast=size(LTimeLast,1);
  ListNbRecordByFile=zeros(nbFileDir,1);
  ListNbRecordByFile(1,1)=nbTime1;
  ListNbRecordByFile(nbFileDir,1)=nbTimeLast;
  for iFile=2:nbFileDir-1
    ListNbRecordByFile(iFile,1)=nbTime2;
  end;
  %
  TheBeginTimeSec=LTime1(1,1);
  nbEnt=size(LTime1, 1);
  if (nbEnt > 1)
    DeltaTimeSec=LTime1(2,1) - LTime1(1,1);
  else
    DeltaTimeSec=0;
  end;
  %
  idx=0;
  idxFile=0;
  eTimeSec=TheBeginTimeSec;
  for iFile=1:nbFileDir
    eFile=[ThePrePrefix H(iFile, 1).name];
%    disp(['eFile=' eFile]);
    idxFile=idxFile+1;
    ListFileUniq{idxFile}=eFile;
    nbRecord=ListNbRecordByFile(iFile,1);
    for iRecord=1:nbRecord
      if (eTimeSec >= BeginTimeSec-TheTolSec && ...
	  eTimeSec <= EndTimeSec+TheTolSec)
	idx=idx+1;
	ListFile{idx}=eFile;
	ListIRecord(idx, 1)=iRecord;
	ListIFileUniq(idx,1)=idxFile;
	ListTimeHistory(idx,1)=eTimeSec;
      end;
%      disp(['eTimeSec=' num2str(eTimeSec) '  BeginTimeSec=' num2str(BeginTimeSec) ' EndTimeSec=' num2str(EndTimeSec)]);
      eTimeSec=eTimeSec+DeltaTimeSec;
    end;
  end;
  nbFile=nbFileDir;
%  disp('return 3');
else
  disp('You chosed another option for your roms files');
  disp('Please program it here');
  error('Please correct');
end;
