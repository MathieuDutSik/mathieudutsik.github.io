function TheRes=DATE_ConvertSix2mjd(...
    eYear, eMonth, eDay, eHour, eMin, eSec)

TheRes=persodate2mjd(eYear, eMonth, eDay, eHour, eMin, eSec);
