function NEST_CreateBoundaryFromHistory(...
    HisPrefix, NestingTotalArray, ...
    BeginTimeDay, EndTimeDay, BoundaryFileName)
%
% --StationFileName is the output by ROMS of the run
% --TheOffset is the move in index that is needed to be
%   made (station file are for multiple purposes)
%   TheOffSet=0 if only for this purpose or it is at the beginning.
HistoryArray=ROMShistoryGetInfoMult5(...
    HisPrefix, BeginTimeDay, EndTimeDay);
nbTime=HistoryArray.nbTime;
%
s_rho=NestingTotalArray.ARVDsma.N;
[test, reason]=IsMakeableFile(BoundaryFileName);
if (test == 0)
  disp(['We cannot create file ' BoundaryFileName]);
  disp(['For reason : ' reason]);
  error('Please correct');
end;
ncBound=netcdf(BoundaryFileName, 'clobber');
NEST_CreateNetcdfBoundaryStruct(...
    ncBound, NestingTotalArray, nbTime, s_rho, ...
    NestingTotalArray.RecordBound);

Day2sec=24*3600;
for iTime=1:nbTime
  iRecord=HistoryArray.ListIRecord(iTime,1);
  HistoryFile=HistoryArray.ListFile{iTime};
  TheState=ReadSingleHistoryRecord(...
      HistoryFile, NestingTotalArray.GrdArrBig, iRecord);
  eTimeSec=TheState.eTime;
  eTimeDay=HistoryArray.ListTimeHistoryDay(iTime,1);
  strPres=DATE_ConvertMjd2mystringPres(eTimeDay);
  disp(['iTime=' num2str(iTime) '/' num2sr(nbTime) ...
	'  date=' strPres ...
	' HisFile=' HistoryFile ' iRecord=' num2str(iRecord)]);
  if (abs(eTimeSec - HistoryArray.ListTimeHistorySec(iTime,1)) > 1000)
    disp(['We have inconsistency in the table of files']);
    disp(['str(eTimeSec)=' ...
	  DATE_ConvertMjd2mystringPres(eTimeSec/Day2sec)]);
    vTimeDay=HistoryArray.ListTimeHistoryDay(iTime,1);
    disp(['str(vTime)=' ...
	  DATE_ConvertMjd2mystringPres(vTimeDay)]);
    error('Please correct');
  end;
  TheStateSma=Interpol_R2R_AllFields(NestingTotalArray, TheState);
  NEST_SingleWriteToBoundState(...
      ncBound, iTime, NestingTotalArray.RecordBound, ...
      TheStateSma);
end;
close(ncBound);
