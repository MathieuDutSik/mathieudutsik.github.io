function TheRec=Interpol_R2R_FindCoefficient2Dgrid(...
    LONbig_rho, LATbig_rho, MSKbig_rho, ...
    LONsma_rho, LATsma_rho, MSKsma_rho);

[a1, b1]=size(LONbig_rho);
[a2, b2]=size(LATbig_rho);
[a3, b3]=size(MSKbig_rho);
if (a1 ~= a2 || a1 ~= a2 || b1 ~= b2 || b1 ~= b2)
  disp(['Concistency error in Interpol_R2R_FindCoefficient2Dgrid']);
  disp(['a=' num2str(a1) ' ' num2str(a2) ' ' num2str(a3)]);
  disp(['b=' num2str(b1) ' ' num2str(b2) ' ' num2str(b3)]);
  error('Please correct');
end;



test=IsSquareGrid(LONsma_rho, LATsma_rho);
disp(['test=' num2str(test)]);
test=1;
% there seems to be some problem related to the
% kind of grid that we are using for the interpolation.
if (test == 0)
  TheRec=Interpol_R2R_FindCoefficient2Dgrid_V1(...
      LONbig_rho, LATbig_rho, MSKbig_rho, ...
      LONsma_rho, LATsma_rho, MSKsma_rho);
else
  TheRec=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
      LONbig_rho, LATbig_rho, MSKbig_rho, ...
      LONsma_rho, LATsma_rho, MSKsma_rho);
end;
