function TotalArray=InterpolGetTotalArray_R2R_fields_kernel(...
    GrdArrBig, GrdArrSma)

LONbig_rho=GrdArrBig.LON_rho;
LATbig_rho=GrdArrBig.LAT_rho;
MSKbig_rho=GrdArrBig.MSK_rho;

LONbig_u=GrdArrBig.LON_u;
LATbig_u=GrdArrBig.LAT_u;
MSKbig_u=GrdArrBig.MSK_u;

LONbig_v=GrdArrBig.LON_v;
LATbig_v=GrdArrBig.LAT_v;
MSKbig_v=GrdArrBig.MSK_v;

ANGbig_rho=GrdArrBig.ANG_rho;
DEPbig_rho=GrdArrBig.DEP_rho;
DEPbig_u=GrdArrBig.DEP_u;
DEPbig_v=GrdArrBig.DEP_v;
%
%
%
%
LONsma_rho=GrdArrSma.LON_rho;
LATsma_rho=GrdArrSma.LAT_rho;
MSKsma_rho=GrdArrSma.MSK_rho;

LONsma_u=GrdArrSma.LON_u;
LATsma_u=GrdArrSma.LAT_u;
MSKsma_u=GrdArrSma.MSK_u;

LONsma_v=GrdArrSma.LON_v;
LATsma_v=GrdArrSma.LAT_v;
MSKsma_v=GrdArrSma.MSK_v;

ANGsma_rho=GrdArrSma.ANG_rho;
DEPsma_rho=GrdArrSma.DEP_rho;
DEPsma_u=GrdArrSma.DEP_u;
DEPsma_v=GrdArrSma.DEP_v;
%
TheRecRR=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_rho, LATbig_rho, MSKbig_rho, ...
    LONsma_rho, LATsma_rho, MSKsma_rho);
%
TheRecUU=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_u, LATbig_u, MSKbig_u, ...
    LONsma_u, LATsma_u, MSKsma_u);
%keyboard;
TheRecUV=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_u, LATbig_u, MSKbig_u, ...
    LONsma_v, LATsma_v, MSKsma_v);
TheRecVU=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_v, LATbig_v, MSKbig_v, ...
    LONsma_u, LATsma_u, MSKsma_u);
TheRecVV=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_v, LATbig_v, MSKbig_v, ...
    LONsma_v, LATsma_v, MSKsma_v);
%
TheRecRU=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_rho, LATbig_rho, MSKbig_rho, ...
    LONsma_u, LATsma_u, MSKsma_u);
TheRecRV=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_rho, LATbig_rho, MSKbig_rho, ...
    LONsma_v, LATsma_v, MSKsma_v);
%
[eta_rho_sma, xi_rho_sma]=size(LONsma_rho);
[eta_u_sma,xi_u_sma]=size(LONsma_u);
[eta_v_sma,xi_v_sma]=size(LONsma_v);
ANGsma_u_big=zeros(eta_u_sma, xi_u_sma);
for iEtaSma=1:eta_u_sma
  for iXiSma=1:xi_u_sma
    eSum=0;
    for idx=1:4
      eWeight=TheRecRU.ListRelCoeff(iEtaSma, iXiSma, idx);
      if (eWeight > 0)
	iEtaBig=TheRecRU.ListRelETA(iEtaSma, iXiSma, idx);
	iXiBig=TheRecRU.ListRelXI(iEtaSma, iXiSma, idx);
	eSum=eSum+ANGbig_rho(iEtaBig, iXiBig)*eWeight;
      end;
    end;
    ANGsma_u_big(iEtaSma, iXiSma)=eSum;
  end;
end;
ANGsma_v_big=zeros(eta_v_sma, xi_v_sma);
for iEtaSma=1:eta_v_sma
  for iXiSma=1:xi_v_sma
    eSum=0;
    for idx=1:4
      eWeight=TheRecRV.ListRelCoeff(iEtaSma, iXiSma, idx);
      if (eWeight > 0)
	iEtaBig=TheRecRV.ListRelETA(iEtaSma, iXiSma, idx);
	iXiBig=TheRecRV.ListRelXI(iEtaSma, iXiSma, idx);
	eSum=eSum+ANGbig_rho(iEtaBig, iXiBig)*eWeight;
      end;
    end;
    ANGsma_v_big(iEtaSma, iXiSma)=eSum;
  end;
end;
%
TotalArray.ListRelETA_rr=TheRecRR.ListRelETA;
TotalArray.ListRelXI_rr=TheRecRR.ListRelXI;
TotalArray.ListRelCoeff_rr=TheRecRR.ListRelCoeff;
TotalArray.ListRelETA_uu=TheRecUU.ListRelETA;
TotalArray.ListRelXI_uu=TheRecUU.ListRelXI;
TotalArray.ListRelCoeff_uu=TheRecUU.ListRelCoeff;
TotalArray.ListRelETA_uv=TheRecUV.ListRelETA;
TotalArray.ListRelXI_uv=TheRecUV.ListRelXI;
TotalArray.ListRelCoeff_uv=TheRecUV.ListRelCoeff;
TotalArray.ListRelETA_vu=TheRecVU.ListRelETA;
TotalArray.ListRelXI_vu=TheRecVU.ListRelXI;
TotalArray.ListRelCoeff_vu=TheRecVU.ListRelCoeff;
TotalArray.ListRelETA_vv=TheRecVV.ListRelETA;
TotalArray.ListRelXI_vv=TheRecVV.ListRelXI;
TotalArray.ListRelCoeff_vv=TheRecVV.ListRelCoeff;
TotalArray.MSKbig_rho=MSKbig_rho;
TotalArray.MSKbig_u=MSKbig_u;
TotalArray.MSKbig_v=MSKbig_v;
TotalArray.MSKsma_rho=MSKsma_rho;
TotalArray.MSKsma_u=MSKsma_u;
TotalArray.MSKsma_v=MSKsma_v;
TotalArray.ANGbig_rho=ANGbig_rho;
TotalArray.ANGsma_rho=ANGsma_rho;
TotalArray.ANGsma_u_big=ANGsma_u_big;
TotalArray.ANGsma_v_big=ANGsma_v_big;
TotalArray.DEPbig_rho=DEPbig_rho;
TotalArray.DEPbig_u=DEPbig_u;
TotalArray.DEPbig_v=DEPbig_v;
TotalArray.DEPsma_rho=DEPsma_rho;
TotalArray.DEPsma_u=DEPsma_u;
TotalArray.DEPsma_v=DEPsma_v;
TotalArray.eta_rho_sma=eta_rho_sma;
TotalArray.xi_rho_sma=xi_rho_sma;
TotalArray.eta_u_sma=eta_u_sma;
TotalArray.xi_u_sma=xi_u_sma;
TotalArray.eta_v_sma=eta_v_sma;
TotalArray.xi_v_sma=xi_v_sma;
