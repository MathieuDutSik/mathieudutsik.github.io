function [b2,n2,b1,n1]=basis1d1_corr(zref,zdes)
% history:  Written by Christopher E. Naimie
%           Dartmouth College
%           26 AUGUST 1992
%           hacked by Mathieu Dutour Sikiric
% zref should be increasing or decreasing.
nn=length(zref);
if (zref(nn) > zref(1))
  [b2,n2,b1,n1]=basis1d1(zref,zdes);
else
  [b2,n2,b1,n1]=basis1d1(-zref,-zdes);
end;
