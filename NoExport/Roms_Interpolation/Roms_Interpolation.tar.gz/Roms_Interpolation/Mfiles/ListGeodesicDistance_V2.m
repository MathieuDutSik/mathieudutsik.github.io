function ListDist=ListGeodesicDistance_V2(...
    ListLon1, ListLat1, eLon, eLat)
nbElt=size(ListLon1,1);

ListLon2=zeros(nbElt,1);
ListLon2(:,1)=eLon;
ListLat2(:,1)=eLat;

ListLonRad1=ListLon1*(pi/180);
ListLatRad1=ListLat1*(pi/180);
x1=cos(ListLonRad1).*cos(ListLatRad1);
y1=sin(ListLonRad1).*cos(ListLatRad1);
z1=sin(ListLatRad1);

ListLonRad2=(eLon*pi/180)*ones(nbElt,1);
ListLatRad2=(eLat*pi/180)*ones(nbElt,1);
x2=cos(ListLonRad2).*cos(ListLatRad2);
y2=sin(ListLonRad2).*cos(ListLatRad2);
z2=sin(ListLatRad2);

XD=x1-x2;
YD=y1-y2;
ZD=z1-z2;

ListDist=sqrt(XD.*XD + YD.*YD + ZD.*ZD);
