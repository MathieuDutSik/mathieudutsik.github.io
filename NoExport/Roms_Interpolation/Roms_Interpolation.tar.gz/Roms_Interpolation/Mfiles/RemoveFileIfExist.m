function RemoveFileIfExist(FileName)


test=exist(FileName, 'file');
if (test ~= 0)
  delete(FileName);
end;
