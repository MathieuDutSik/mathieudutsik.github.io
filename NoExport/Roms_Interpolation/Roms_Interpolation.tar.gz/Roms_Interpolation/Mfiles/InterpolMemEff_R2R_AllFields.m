function NewState=InterpolMemEff_R2R_AllFields(...
    TotalArray, ARVDbig, ARVDsma, OldState)
%
% NewState=InterpolMemEff_R2R_AllFields(TotalArray, ARVDbig, ARVDsma, OldState)
%   NewState and OldState contains ZETA, UBAR, VBAR, TEMP, SALT, U, V
%   and they are interpolated from the big grid to the small one
%   according to the TotalArray interpolation fields and the
%   ARVDbig, ARVDsma vertical discretization
%
ZETAsma=InterpolMemEff_R2R_2Dfield(TotalArray, OldState.ZETA);
[UBARsma, VBARsma]=InterpolMemEff_R2R_2Duvfield(...
    TotalArray, OldState.UBAR, OldState.VBAR);
TEMPsma=InterpolMemEff_R2R_3Dfield(...
    TotalArray, ARVDbig, ARVDsma, ...
    OldState.TEMP);
SALTsma=InterpolMemEff_R2R_3Dfield(...
    TotalArray, ARVDbig, ARVDsma, OldState.SALT);
[Usma, Vsma]=InterpolMemEff_R2R_3Duvfield(...
    TotalArray, ARVDbig, ARVDsma, ...
    OldState.U, OldState.V);
NewState.ZETA=ZETAsma;
NewState.TEMP=TEMPsma;
NewState.SALT=SALTsma;
NewState.UBAR=UBARsma;
NewState.VBAR=VBARsma;
NewState.U=Usma;
NewState.V=Vsma;
NewState.eTime=OldState.eTime;
