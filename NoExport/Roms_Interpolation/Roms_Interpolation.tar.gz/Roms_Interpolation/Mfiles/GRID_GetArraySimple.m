function TheArray=GRID_GetArraySimple(GridFile)
if (IsExistingFile(GridFile) == 0)
  disp(['GridFile=' GridFile]);
  disp('We are sorry, but we need a grid file, which can be read');
  error('Correct your input');
end;
%
TheAPI=GetAPItype();

TheArray.Nature='ROMS';
if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
  nc=netcdf(GridFile, 'nowrite');
  F_rho=nc{'lon_rho'}(:);
  [eta_rho_f, xi_rho_f]=size(F_rho);
  if (eta_rho_f > 0 && xi_rho_f > 0)
    LON_rho=nc{'lon_rho'}(:);
    LAT_rho=nc{'lat_rho'}(:);
    LON_psi=nc{'lon_psi'}(:);
    LAT_psi=nc{'lat_psi'}(:);
    LON_u=nc{'lon_u'}(:);
    LAT_u=nc{'lat_u'}(:);
    LON_v=nc{'lon_v'}(:);
    LAT_v=nc{'lat_v'}(:);
  else
    LON_rho=nc{'x_rho'}(:);
    LAT_rho=nc{'y_rho'}(:);
    LON_psi=nc{'x_psi'}(:);
    LAT_psi=nc{'y_psi'}(:);
    LON_u=nc{'x_u'}(:);
    LAT_u=nc{'y_u'}(:);
    LON_v=nc{'x_v'}(:);
    LAT_v=nc{'y_v'}(:);
  end;
  MSK_rho=nc{'mask_rho'}(:);
  MSK_u_read=nc{'mask_u'}(:);
  MSK_v_read=nc{'mask_v'}(:);
  MSK_psi_read=nc{'mask_psi'}(:);
  DEP_rho=nc{'h'}(:);
  ANG_rho=nc{'angle'}(:);
  pm_rho=nc{'pm'}(:);
  pn_rho=nc{'pn'}(:);
  fCoriolis=nc{'f'}(:);
  dndx=nc{'dndx'}(:);
  dmde=nc{'dmde'}(:);
  %
  x_rho=nc{'x_rho'}(:);
  y_rho=nc{'y_rho'}(:);
  if (size(x_rho, 1) > 0)
    TheArray.x_rho=x_rho;
    TheArray.y_rho=y_rho;
    HaveXrho=1;
  else
    HaveXrho=0;
  end;
  %
  x_u=nc{'x_u'}(:);
  y_u=nc{'y_u'}(:);
  if (size(x_u, 1) > 0)
    TheArray.x_u=x_u;
    TheArray.y_u=y_u;
    HaveXu=1;
  else
    HaveXu=0;
  end;
  %
  x_v=nc{'x_v'}(:);
  y_v=nc{'y_v'}(:);
  if (size(x_v, 1) > 0)
    TheArray.x_v=x_v;
    TheArray.y_v=y_v;
    HaveXv=1;
  else
    HaveXv=0;
  end;
  %
  x_psi=nc{'x_psi'}(:);
  y_psi=nc{'y_psi'}(:);
  if (size(x_psi, 1) > 0)
    TheArray.x_psi=x_psi;
    TheArray.y_psi=y_psi;
    HaveXpsi=1;
  else
    HaveXpsi=0;
  end;
  %
  close(nc);
else
  test = nc_isvar(GridFile, 'lon_rho');
  if (test == 1)
    LON_rho=nc_varget(GridFile, 'lon_rho');
    LAT_rho=nc_varget(GridFile, 'lat_rho');
    LON_psi=nc_varget(GridFile, 'lon_psi');
    LAT_psi=nc_varget(GridFile, 'lat_psi');
    LON_u=nc_varget(GridFile, 'lon_u');
    LAT_u=nc_varget(GridFile, 'lat_u');
    LON_v=nc_varget(GridFile, 'lon_v');
    LAT_v=nc_varget(GridFile, 'lat_v');
  else
    LON_rho=nc_varget(GridFile, 'x_rho');
    LAT_rho=nc_varget(GridFile, 'y_rho');
    LON_psi=nc_varget(GridFile, 'x_psi');
    LAT_psi=nc_varget(GridFile, 'y_psi');
    LON_u=nc_varget(GridFile, 'x_u');
    LAT_u=nc_varget(GridFile, 'y_u');
    LON_v=nc_varget(GridFile, 'x_v');
    LAT_v=nc_varget(GridFile, 'y_v');
  end;
  MSK_rho=nc_varget(GridFile, 'mask_rho');
  MSK_u_read=nc_varget(GridFile, 'mask_u');
  MSK_v_read=nc_varget(GridFile, 'mask_v');
  MSK_psi_read=nc_varget(GridFile, 'mask_psi');
  
  DEP_rho=nc_varget(GridFile, 'h');
  ANG_rho=nc_varget(GridFile, 'angle');
  pm_rho=nc_varget(GridFile, 'pm');
  pn_rho=nc_varget(GridFile, 'pn');
  fCoriolis=nc_varget(GridFile, 'f');
  dndx=nc_varget(GridFile, 'dndx');
  dmde=nc_varget(GridFile, 'dmde');
  %
  test = nc_isvar(GridFile, 'x_rho');
  if (test == 1)
    x_rho=nc_varget(GridFile, 'x_rho');
    y_rho=nc_varget(GridFile, 'y_rho');
    TheArray.x_rho=x_rho;
    TheArray.y_rho=y_rho;
    HaveXrho=1;
  else
    HaveXrho=0;
  end;
  %
  test = nc_isvar(GridFile, 'x_u');
  if (test == 1)
    x_u=nc_varget(GridFile, 'x_u');
    y_u=nc_varget(GridFile, 'y_u');
    TheArray.x_u=x_u;
    TheArray.y_u=y_u;
    HaveXu=1;
  else
    HaveXu=0;
  end;
  %
  test = nc_isvar(GridFile, 'x_v');
  if (test == 1)
    x_v=nc_varget(GridFile, 'x_v');
    y_v=nc_varget(GridFile, 'y_v');
    TheArray.x_v=x_v;
    TheArray.y_v=y_v;
    HaveXv=1;
  else
    HaveXv=0;
  end;
  %
  test = nc_isvar(GridFile, 'x_psi');
  if (test == 1)
    x_psi=nc_varget(GridFile, 'x_psi');
    y_psi=nc_varget(GridFile, 'y_psi');
    TheArray.x_psi=x_psi;
    TheArray.y_psi=y_psi;
    HaveXpsi=1;
  else
    HaveXpsi=0;
  end;
end;

TheArray.GridFile=GridFile;
TheArray.LON_rho=LON_rho;
TheArray.LAT_rho=LAT_rho;
TheArray.LON_psi=LON_psi;
TheArray.LAT_psi=LAT_psi;
TheArray.LON_u=LON_u;
TheArray.LAT_u=LAT_u;
TheArray.LON_v=LON_v;
TheArray.LAT_v=LAT_v;
TheArray.fCoriolis=fCoriolis;
%
TheArray.dndx=dndx;
TheArray.dmde=dmde;
%
[eta_rho, xi_rho]=size(MSK_rho);
[eta_u, xi_u]=size(MSK_u_read);
[eta_v, xi_v]=size(MSK_v_read);
eta_psi=eta_rho-1;
xi_psi=xi_rho-1;
TheArray.eta_rho=eta_rho;
TheArray.eta_psi=eta_psi;
TheArray.eta_u=eta_u;
TheArray.eta_v=eta_v;
TheArray.xi_rho=xi_rho;
TheArray.xi_psi=xi_psi;
TheArray.xi_u=xi_u;
TheArray.xi_v=xi_v;
%
SIZ_rho=eta_rho*xi_rho;
SIZ_u=eta_u*xi_u;
SIZ_v=eta_v*xi_v;
SIZ_uv=SIZ_u+SIZ_v;
TheArray.SIZ_rho=SIZ_rho;
TheArray.SIZ_u=SIZ_u;
TheArray.SIZ_v=SIZ_v;
TheArray.SIZ_uv=SIZ_uv;
%
MSK_v=MSK_rho(1:eta_rho-1,:).*MSK_rho(2:eta_rho,:);
MSK_u=MSK_rho(:,1:xi_rho-1).*MSK_rho(:,2:xi_rho);
MSK_psi=MSK_rho(1:eta_rho-1,1:xi_rho-1).*...
        MSK_rho(2:eta_rho,1:xi_rho-1).*...
        MSK_rho(1:eta_rho-1,2:xi_rho).*...
        MSK_rho(2:eta_rho,2:xi_rho);
MSKdist_u=sum(abs(MSK_u(:) - MSK_u_read(:)));
MSKdist_v=sum(abs(MSK_v(:) - MSK_v_read(:)));
MSKdist_psi=sum(abs(MSK_psi(:) - MSK_psi_read(:)));
if (MSKdist_u > 1/2 || MSKdist_v > 1/2 || MSKdist_psi > 1/2)
  disp('The mask of your grid are not correct!!!!');
  error('Please correct');
end;


TheArray.MSK_rho=MSK_rho;
TheArray.MSK_psi=MSK_psi;
TheArray.MSK_u=MSK_u;
TheArray.MSK_v=MSK_v;
MSKbound_rho=zeros(eta_rho, xi_rho);
MSKbound_rho(1, :)=1;
MSKbound_rho(:, 1)=1;
MSKbound_rho(eta_rho, :)=1;
MSKbound_rho(:, xi_rho)=1;
Kbound_rho=find(MSKbound_rho == 1);
TheArray.MSKbound_rho=MSKbound_rho;
TheArray.Kbound_rho=Kbound_rho;
%
ETA_rho=zeros(eta_rho,xi_rho);
XI_rho=zeros(eta_rho,xi_rho);
for iEta=1:eta_rho
  for iXi=1:xi_rho
    ETA_rho(iEta, iXi)=iEta;
    XI_rho(iEta, iXi)=iXi;
  end;
end;
ETA_u=zeros(eta_u,xi_u);
XI_u=zeros(eta_u,xi_u);
for iEta=1:eta_u
  for iXi=1:xi_u
    ETA_u(iEta, iXi)=iEta;
    XI_u(iEta, iXi)=iXi;
  end;
end;
ETA_v=zeros(eta_v,xi_v);
XI_v=zeros(eta_v,xi_v);
for iEta=1:eta_v
  for iXi=1:xi_v
    ETA_v(iEta, iXi)=iEta;
    XI_v(iEta, iXi)=iXi;
  end;
end;
TheArray.ETA_rho=ETA_rho;
TheArray.XI_rho=XI_rho;
TheArray.ETA_u=ETA_u;
TheArray.XI_u=XI_u;
TheArray.ETA_v=ETA_v;
TheArray.XI_v=XI_v;
%
[eta_rho_ang, xi_rho_ang]=size(ANG_rho);
if (eta_rho_ang > 0 && xi_rho_ang > 0)
  ANG_u=(ANG_rho(:, 1:xi_u)+ANG_rho(:, 2:xi_rho))/2;
  ANG_v=(ANG_rho(1:eta_v, :)+ANG_rho(2:eta_rho, :))/2;
  ANG_psi=(ANG_rho(1:eta_rho-1,1:xi_rho-1)+...
           ANG_rho(2:eta_rho,1:xi_rho-1)+...
           ANG_rho(1:eta_rho-1,2:xi_rho)+...
           ANG_rho(2:eta_rho,2:xi_rho))/4;
else
  ANG_rho=zeros(eta_rho, xi_rho);
  ANG_u=zeros(eta_u, xi_u);
  ANG_v=zeros(eta_v, xi_v);
  ANG_psi=zeros(eta_psi, xi_psi);
end;
TheArray.ANG_rho=ANG_rho;
TheArray.ANG_psi=ANG_psi;
TheArray.ANG_u=ANG_u;
TheArray.ANG_v=ANG_v;
%
%
DEP_u=(DEP_rho(:, 1:xi_u)+DEP_rho(:, 2:xi_rho))/2;
DEP_v=(DEP_rho(1:eta_v, :)+DEP_rho(2:eta_rho, :))/2;
DEP_psi=(DEP_rho(1:eta_rho-1,1:xi_rho-1)+...
           DEP_rho(2:eta_rho,1:xi_rho-1)+...
           DEP_rho(1:eta_rho-1,2:xi_rho)+...
           DEP_rho(2:eta_rho,2:xi_rho))/4;
TheArray.DEP_rho=DEP_rho;
TheArray.DEP_psi=DEP_psi;
TheArray.DEP_u=DEP_u;
TheArray.DEP_v=DEP_v;
%
mn_rho=pm_rho.*pn_rho;
mn_psi=(mn_rho(1:eta_rho-1,1:xi_rho-1)+mn_rho(1:eta_rho-1,2:xi_rho)+...
	mn_rho(2:eta_rho,2:xi_rho)+mn_rho(2:eta_rho,1:xi_rho-1))/4;
TheArray.pm_rho=pm_rho;
TheArray.pn_rho=pn_rho;
TheArray.pm=pm_rho;
TheArray.pn=pn_rho;
TheArray.mn_rho=mn_rho;
TheArray.mn_psi=mn_psi;
%
KlandPsi=find(MSK_psi == 0);
KseaPsi=find(MSK_psi == 1);
KlandRho=find(MSK_rho == 0);
KseaRho=find(MSK_rho == 1);
KlandU=find(MSK_u == 0);
KseaU=find(MSK_u == 1);
KlandV=find(MSK_v == 0);
KseaV=find(MSK_v == 1);
TheArray.KlandPsi=KlandPsi;
TheArray.KseaPsi=KseaPsi;
TheArray.KlandRho=KlandRho;
TheArray.KseaRho=KseaRho;
TheArray.KlandU=KlandU;
TheArray.KseaU=KseaU;
TheArray.KlandV=KlandV;
TheArray.KseaV=KseaV;
%
SigSize=[num2str(eta_rho) 'x' num2str(xi_rho)];
TheArray.SigSize=SigSize;
%
LONnorth_u=LON_u(eta_u,:);
LONsouth_u=LON_u(1,:);
LONwest_u=LON_u(:,1);
LONeast_u=LON_u(:,xi_u);
LATnorth_u=LAT_u(eta_u,:);
LATsouth_u=LAT_u(1,:);
LATwest_u=LAT_u(:,1);
LATeast_u=LAT_u(:,xi_u);
ANGnorth_u=ANG_u(eta_u,:);
ANGsouth_u=ANG_u(1,:);
ANGwest_u=ANG_u(:,1);
ANGeast_u=ANG_u(:,xi_u);
LONnorth_v=LON_v(eta_v,:);
LONsouth_v=LON_v(1,:);
LONwest_v=LON_v(:,1);
LONeast_v=LON_v(:,xi_v);
LATnorth_v=LAT_v(eta_v,:);
LATsouth_v=LAT_v(1,:);
LATwest_v=LAT_v(:,1);
LATeast_v=LAT_v(:,xi_v);
ANGnorth_v=ANG_v(eta_v,:);
ANGsouth_v=ANG_v(1,:);
ANGwest_v=ANG_v(:,1);
ANGeast_v=ANG_v(:,xi_v);
%
LONbound=GRID_GetBound(LON_rho);
LATbound=GRID_GetBound(LAT_rho);
TheArray.LONbound=LONbound;
TheArray.LATbound=LATbound;
%
nbWetRho=size(KseaRho,1);
nbWetPsi=size(KseaPsi,1);
nbWetU=size(KseaU,1);
nbWetV=size(KseaV,1);
nbWetUV=nbWetU+nbWetV;
TheArray.nbWetRho=nbWetRho;
TheArray.nbWetPsi=nbWetPsi;
TheArray.nbWetU=nbWetU;
TheArray.nbWetV=nbWetV;
TheArray.nbWetUV=nbWetUV;
TheArray.xy_rho=nbWetRho;
TheArray.xy_u=nbWetU;
TheArray.xy_v=nbWetV;
TheArray.xy_psi=nbWetPsi;
%
LookUpRho=zeros(eta_rho, xi_rho);
idx=0;
for iEta=1:eta_rho
  for iXi=1:xi_rho
    if (MSK_rho(iEta, iXi) == 1)
      idx=idx+1;
      LookUpRho(iEta, iXi)=idx;
    end;
  end;
end;
LookUpU=zeros(eta_u, xi_u);
idx=0;
for iEta=1:eta_u
  for iXi=1:xi_u
    if (MSK_u(iEta, iXi) == 1)
      idx=idx+1;
      LookUpU(iEta, iXi)=idx;
    end;
  end;
end;
%
LookUpV=zeros(eta_v, xi_v);
idx=0;
for iEta=1:eta_v
  for iXi=1:xi_v
    if (MSK_v(iEta, iXi) == 1)
      idx=idx+1;
      LookUpV(iEta, iXi)=idx;
    end;
  end;
end;
%
TheArray.LookUpRho=LookUpRho;
TheArray.LookUpU=LookUpU;
TheArray.LookUpV=LookUpV;
%
[LON_psi2, LAT_psi2, MSK_psi2, DEP_psi2]=GRID_ExtendedPsiThi(...
    MSK_rho, LON_rho, LAT_rho, LON_psi, LAT_psi, ...
    LON_u, LAT_u, LON_v, LAT_v, ...
    DEP_rho, DEP_u, DEP_v, DEP_psi);
TheArray.LON_psi2=LON_psi2;
TheArray.LAT_psi2=LAT_psi2;
TheArray.MSK_psi2=MSK_psi2;
TheArray.DEP_psi2=DEP_psi2;
%
if (HaveXrho == 1 && HaveXu == 1 && HaveXv == 1 && ...
    HaveXpsi == 1)
  [x_psi2, y_psi2, MSKb_psi2, DEPb_psi2]=GRID_ExtendedPsiThi(...
      MSK_rho, x_rho, y_rho, x_psi, y_psi, ...
      x_u, y_u, x_v, y_v, ...
      DEP_rho, DEP_u, DEP_v, DEP_psi);
  TheArray.x_psi2=x_psi2;
  TheArray.y_psi2=y_psi2;
end;
%
MinLon=min(LON_rho(KseaRho));
MaxLon=max(LON_rho(KseaRho));
MinLat=min(LAT_rho(KseaRho));
MaxLat=max(LAT_rho(KseaRho));
TheArray.MinLon=MinLon;
TheArray.MaxLon=MaxLon;
TheArray.MinLat=MinLat;
TheArray.MaxLat=MaxLat;
TheArray.TheQuad=[MinLon MaxLon MinLat MaxLat];
%
if (HaveXrho == 1)
  MinX=min(x_rho(KseaRho));
  MaxX=max(x_rho(KseaRho));
  MinY=min(y_rho(KseaRho));
  MaxY=max(y_rho(KseaRho));
  TheArray.MinX=MinX;
  TheArray.MaxX=MaxX;
  TheArray.MinY=MinY;
  TheArray.MaxY=MaxY;
  TheArray.TheQuadX=[MinX MaxX MinY MaxY];
end;


%
LONsel=LON_rho(:,xi_rho);
LATsel=LAT_rho(:,xi_rho);
MinLonEast=min(LONsel);
MaxLonEast=max(LONsel);
MinLatEast=min(LATsel);
MaxLatEast=max(LATsel);
TheArray.TheQuadEast=[MinLonEast MaxLonEast MinLatEast MaxLatEast];
MSKeast=MSK_rho(:,xi_rho);
Keast=find(MSKeast == 1);
nbEast=size(Keast,1);
TheArray.nbEast=nbEast;
TheArray.TheQuadEastRed=[min(LONsel(Keast)) max(LONsel(Keast)) ...
		    min(LATsel(Keast)) max(LATsel(Keast))];
%
MinLonWest=min(LON_rho(:,1));
MaxLonWest=max(LON_rho(:,1));
MinLatWest=min(LAT_rho(:,1));
MaxLatWest=max(LAT_rho(:,1));
TheArray.TheQuadWest=[MinLonWest MaxLonWest MinLatWest MaxLatWest];
MSKwest=MSK_rho(:,1);
Kwest=find(MSKwest == 1);
nbWest=size(Kwest,1);
TheArray.nbWest=nbWest;
%
MinLonNorth=min(LON_rho(eta_rho,:));
MaxLonNorth=max(LON_rho(eta_rho,:));
MinLatNorth=min(LAT_rho(eta_rho,:));
MaxLatNorth=max(LAT_rho(eta_rho,:));
TheArray.TheQuadNorth=[MinLonNorth MaxLonNorth MinLatNorth MaxLatNorth];
MSKnorth=MSK_rho(eta_rho,:);
Knorth=find(MSKnorth == 1);
nbNorth=size(Knorth,1);
TheArray.nbNorth=nbNorth;
%
MinLonSouth=min(LON_rho(1,:));
MaxLonSouth=max(LON_rho(1,:));
MinLatSouth=min(LAT_rho(1,:));
MaxLatSouth=max(LAT_rho(1,:));
MSKsouth=MSK_rho(1,:);
Ksouth=find(MSKsouth == 1);
nbSouth=size(Ksouth,1);
KseaRhoSouth=find(LON_rho >= MinLonSouth & LON_rho <= MaxLonSouth & ...
		  LAT_rho >= MinLatSouth & LAT_rho <= MaxLatSouth & ...
		  MSK_rho == 1);
TheArray.TheQuadSouth=[MinLonSouth MaxLonSouth MinLatSouth MaxLatSouth];
TheArray.nbSouth=nbSouth;
TheArray.KseaRhoSouth=KseaRhoSouth;
%
[str1, str2, str3, str4, ...
 str5, str6, str7, str8]=GRID_GetEWNSinfo(MSK_rho);
TheArray.str1=str1;
TheArray.str2=str2;
TheArray.str3=str3;
TheArray.str4=str4;
TheArray.str5=str5;
TheArray.str6=str6;
TheArray.str7=str7;
TheArray.str8=str8;
%
TheRecMSK=GRID_GetBoundaryMasks(MSK_rho);
TheArray.KsouthSelect=TheRecMSK.KsouthSelect;
TheArray.KnorthSelect=TheRecMSK.KnorthSelect;
TheArray.KwestSelect=TheRecMSK.KwestSelect;
TheArray.KeastSelect=TheRecMSK.KeastSelect;
