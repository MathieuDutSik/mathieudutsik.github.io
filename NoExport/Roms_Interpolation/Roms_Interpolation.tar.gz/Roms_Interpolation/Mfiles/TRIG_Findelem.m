function TheReply=TRIG_Findelem(ListTrig, ListNode, PT)

nbTrig=size(ListTrig, 1);
LSi=[1 2 3];
LSj=[2 3 1];
LSk=[3 1 2];

PTmat=zeros(nbTrig,2);
PTmat(:,1)=PT(1,1);
PTmat(:,2)=PT(1,2);



CResultStrict=zeros(nbTrig, 3);
CResultLarge=zeros(nbTrig, 3);
for iPos=1:3
  iNode=ListTrig(:,LSi(1,iPos));
  jNode=ListTrig(:,LSj(1,iPos));
  kNode=ListTrig(:,LSk(1,iPos));
  V1=ListNode(jNode,:)-ListNode(iNode,:);
  V2=ListNode(kNode,:)-ListNode(iNode,:);
  Vdiff=PTmat-ListNode(iNode,:);
  det1=V1(:,1).*V2(:,2)-V1(:,2).*V2(:,1);
  det2=V1(:,1).*Vdiff(:,2)-V1(:,2).*Vdiff(:,1);
  ScalProdStrict=det1.*det2 > 0;
  CResultStrict(:,iPos)=ScalProdStrict;
  ScalProdLarge=det1.*det2 >= 0;
  CResultLarge(:,iPos)=ScalProdLarge;
end;
CBelongStrict=CResultStrict(:,1).*CResultStrict(:,2).*CResultStrict(:,3);
ListReplyStrict=find(CBelongStrict == 1);
nbBelongStrict=size(ListReplyStrict,1);
if (nbBelongStrict > 1)
  disp(['The vertex belongs to ' num2str(nbBelongStrict) ' triangles']);
  error('Please correct');
end;
if (nbBelongStrict == 0)
  CBelongLarge=CResultLarge(:,1).*CResultLarge(:,2).*CResultLarge(:,3);
  ListReplyLarge=find(CBelongLarge == 1);
  nbBelongLarge=size(ListReplyLarge, 1);
  if (nbBelongLarge > 0)
    TheReply=ListReplyLarge(1,1);
  else
    TheReply=-1;
  end;
else
  TheReply=ListReplyStrict(1,1);
end;
