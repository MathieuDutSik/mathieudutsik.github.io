function TheArray=GRID_GetArray(GridFile)
%
% TheArray=GRID_GetArray(GridFile)
% returns an array containing various grid informations.
% you might prefer to use GRID_ArraySimple
% which is less time consuming for less informations.
%

TheArray=GRID_GetArraySimple(GridFile);
%
RMat=GRID_RoughnessMatrix(TheArray.DEP_rho, TheArray.MSK_rho);
rx0=max(RMat(:));
TheArray.RMat=RMat;
TheArray.rx0=rx0;
%
[ListConn, nbConn]=GRID_ConnectedComponents(TheArray.MSK_rho);
TheArray.ListConn=ListConn;
TheArray.nbConn=nbConn;
%
minDepth=min(TheArray.DEP_rho(TheArray.KseaRho));
TheArray.minDepth=minDepth;
%
InflMatrixSph_rho=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_rho, TheArray.LAT_rho, 'spherical');
InflMatrixSph_u=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_u, TheArray.LAT_u, 'spherical');
InflMatrixSph_v=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_v, TheArray.LAT_v, 'spherical');
InflMatrixSph_psi=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_psi, TheArray.LAT_psi, 'spherical');
InflMatrixEuc_rho=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_rho, TheArray.LAT_rho, 'euclidean');
InflMatrixEuc_u=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_u, TheArray.LAT_u, 'euclidean');
InflMatrixEuc_v=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_v, TheArray.LAT_v,'euclidean');
InflMatrixEuc_psi=GRID_GetMaxRadiusInfluence_kernel(...
    TheArray.LON_psi, TheArray.LAT_psi, 'euclidean');
TheArray.InflMatrixSph_rho=InflMatrixSph_rho;
TheArray.InflMatrixSph_u=InflMatrixSph_u;
TheArray.InflMatrixSph_v=InflMatrixSph_v;
TheArray.InflMatrixSph_psi=InflMatrixSph_psi;
TheArray.InflMatrixEuc_rho=InflMatrixEuc_rho;
TheArray.InflMatrixEuc_u=InflMatrixEuc_u;
TheArray.InflMatrixEuc_v=InflMatrixEuc_v;
TheArray.InflMatrixEuc_psi=InflMatrixEuc_psi;
%


[nbPositive, nbNegative]=GRID_GridOrientationInfo(...
    TheArray.LON_rho, TheArray.LAT_rho);
if (nbPositive > 0 && nbNegative == 0)
  TheOrientation='positive';
elseif (nbPositive == 0 && nbNegative > 0)
  TheOrientation='negative';
else
  TheOrientation='unknown';
end;
TheArray.TheOrientation=TheOrientation;
%
result=GRID_SpatialDisc(...
    TheArray.MSK_rho, TheArray.LON_rho, TheArray.LAT_rho);
TheArray.TheOrientation=TheOrientation;
TheArray.MaxDist_ETA=result.MaxDist_ETA;
TheArray.MinDist_ETA=result.MinDist_ETA;
TheArray.AveDist_ETA=result.AveDist_ETA;
TheArray.MaxDist_XI=result.MaxDist_XI;
TheArray.MinDist_XI=result.MinDist_XI;
TheArray.AveDist_XI=result.AveDist_XI;
%
[WidthU, WidthV]=GRID_GetWidthMatrices(TheArray.LON_psi2, TheArray.LAT_psi2);
TheArray.WidthU=WidthU;
TheArray.WidthV=WidthV;
%
EarthRadius=6367000;
xl=EarthRadius*GeodesicDistance(...
    [TheArray.LON_rho(1,1), TheArray.LAT_rho(1,1)], ...
    [TheArray.LON_rho(1,TheArray.xi_rho), TheArray.LAT_rho(1,TheArray.xi_rho)]);
el=EarthRadius*GeodesicDistance(...
    [TheArray.LON_rho(1,1), TheArray.LAT_rho(1,1)], ...
    [TheArray.LON_rho(TheArray.eta_rho,1), TheArray.LAT_rho(TheArray.eta_rho,1)]);
TheArray.xl=xl;
TheArray.el=el;
