function TheRec=Interpol_R2R_FindCoefficient2Dgrid_nocheck_V2(...
    LONbig_rho, LATbig_rho, MSKbig_rho, ...
    LONsma_rho, LATsma_rho, MSKsma_rho)

[eta_rho_sma, xi_rho_sma]=size(MSKsma_rho);
[eta_rho_big, xi_rho_big]=size(MSKbig_rho);
disp('Before call to Interpol_R2R_GetCoefficients_V2');
[ListETA, ListXI, ListCoeff]=...
    Interpol_R2R_GetCoefficients_V2(...
	LONbig_rho, LATbig_rho, ...
	LONsma_rho, LATsma_rho);
disp(' After call to Interpol_R2R_GetCoefficients_V2');

KseaSma=find(MSKsma_rho == 1);
nbWetSma=size(KseaSma,1);
ListETAsel=ListETA(KseaSma);
ListXIsel=ListXI(KseaSma);
ListCoeffSel=zeros(nbWetSma,4);
ListLON=LONsma_rho(KseaSma);
ListLAT=LATsma_rho(KseaSma);
for i=1:4
  H=squeeze(ListCoeff(:, :, i));
  ListCoeffSel(:, i)=H(KseaSma);
end;
TheRecPrev=Interpol_FindCoefficient2DgridKernel(...
    LONbig_rho, LATbig_rho, MSKbig_rho, ...
    ListLON, ListLAT, ...
    ListETAsel, ListXIsel, ListCoeffSel);

ListRelETA=zeros(eta_rho_sma, xi_rho_sma, 4);
ListRelXI=zeros(eta_rho_sma, xi_rho_sma, 4);
ListRelCoeff=zeros(eta_rho_sma, xi_rho_sma, 4);
H=zeros(eta_rho_sma, xi_rho_sma);
for i=1:4
  H(KseaSma)=TheRecPrev.ListRelETA(:, i);
  ListRelETA(:, :, i)=H;
  H(KseaSma)=TheRecPrev.ListRelXI(:, i);
  ListRelXI(:, :, i)=H;
  H(KseaSma)=TheRecPrev.ListRelCoeff(:, i);
  ListRelCoeff(:, :, i)=H;
end;
TheRec.ListRelETA=ListRelETA;
TheRec.ListRelXI=ListRelXI;
TheRec.ListRelCoeff=ListRelCoeff;
TheRec.MSKused=TheRecPrev.MSKused;
%
TheRec.ListETA_native=ListETA;
TheRec.ListXI_native=ListXI;
TheRec.ListCoeff_native=ListCoeff;
%
TheRec.ListRelETA_rr=ListRelETA;
TheRec.ListRelXI_rr=ListRelXI;
TheRec.ListRelCoeff_rr=ListRelCoeff;
TheRec.MSKbig_rho=MSKbig_rho;
TheRec.MSKsma_rho=MSKsma_rho;
