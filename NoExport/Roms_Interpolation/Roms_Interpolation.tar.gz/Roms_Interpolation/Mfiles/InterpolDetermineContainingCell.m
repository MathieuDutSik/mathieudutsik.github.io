function [ListETA, ListXI, ListCoeff]=...
    InterpolDetermineContainingCell(...
	LON_rho, LAT_rho, ...
	ListLON, ListLAT, ...
	ListGuessETA, ListGuessXI)

[eta_rho, xi_rho]=size(LON_rho);
nbNode=size(ListLON,1);
ListETA=zeros(nbNode,1);
ListXI=zeros(nbNode,1);
ListCoeff=zeros(nbNode,4);
TheExp=2;
nbAssigned=0;
nbNonAssigned=0;
minDiffLON=0;
maxDiffLON=0;
minDiffLAT=0;
maxDiffLAT=0;
for iNode=1:nbNode
%  disp(['iNode=' num2str(iNode) '/' num2str(nbNode)]);
  B=[1 ListLON(iNode,1) ListLAT(iNode,1)];
  GuessEta=ListGuessETA(iNode,1);
  GuessXi=ListGuessXI(iNode,1);
  IsMatched=0;
  for iEta=GuessEta-TheExp:GuessEta+TheExp
    if (iEta > 0 && iEta < eta_rho)
      for iXi=GuessXi-TheExp:GuessXi+TheExp
	if (iXi > 0 && iXi < xi_rho)
	  if (IsMatched == 0)
	    A1(1,:)=[1 LON_rho(iEta, iXi) LAT_rho(iEta,iXi)];
	    A1(2,:)=[1 LON_rho(iEta+1, iXi) LAT_rho(iEta+1,iXi)];
	    A1(3,:)=[1 LON_rho(iEta, iXi+1) LAT_rho(iEta,iXi+1)];
	    eSol1=B*inv(A1);
	    lambda1=eSol1(1,2);
	    lambda2=eSol1(1,3);
	    eCoeff00=(1-lambda1)*(1-lambda2);
	    eCoeff10=lambda1*(1-lambda2);
	    eCoeff01=(1-lambda1)*lambda2;
	    eCoeff11=lambda1*lambda2;
	    if (eCoeff00 >= 0 && eCoeff10 >= 0 && ...
		eCoeff01 >= 0 && eCoeff11 >= 0)
	      IsMatched=1;
	      iEtaSought=iEta;
	      iXiSought=iXi;
	      DiffLON=ListLON(iNode,1) ...
		      - eCoeff00*LON_rho(iEta,iXi) ...
		      - eCoeff10*LON_rho(iEta+1,iXi) ...
		      - eCoeff01*LON_rho(iEta,iXi+1) ...
		      - eCoeff11*LON_rho(iEta+1,iXi+1);
	      DiffLAT=ListLAT(iNode,1) ...
		      - eCoeff00*LAT_rho(iEta,iXi) ...
		      - eCoeff10*LAT_rho(iEta+1,iXi) ...
		      - eCoeff01*LAT_rho(iEta,iXi+1) ...
		      - eCoeff11*LAT_rho(iEta+1,iXi+1);
	    end;
	  end;
	  if (IsMatched == 0)
	    A2(1,:)=[1 LON_rho(iEta+1, iXi+1) LAT_rho(iEta+1,iXi+1)];
	    A2(2,:)=[1 LON_rho(iEta+1, iXi) LAT_rho(iEta+1,iXi)];
	    A2(3,:)=[1 LON_rho(iEta, iXi+1) LAT_rho(iEta,iXi+1)];
	    eSol2=B*inv(A2);
	    lambda1=eSol2(1,3);
	    lambda2=eSol2(1,2);
	    eCoeff00=lambda1*lambda2;
	    eCoeff10=(1-lambda1)*lambda2;
	    eCoeff01=lambda1*(1-lambda2);
	    eCoeff11=(1-lambda1)*(1-lambda2);
	    if (eCoeff00 >= 0 && eCoeff10 >= 0 && ...
		eCoeff01 >= 0 && eCoeff11 >= 0)
	      IsMatched=1;
	      iEtaSought=iEta;
	      iXiSought=iXi;
	      DiffLON=ListLON(iNode,1) ...
		      - eCoeff00*LON_rho(iEta,iXi) ...
		      - eCoeff10*LON_rho(iEta+1,iXi) ...
		      - eCoeff01*LON_rho(iEta,iXi+1) ...
		      - eCoeff11*LON_rho(iEta+1,iXi+1);
	      DiffLAT=ListLAT(iNode,1) ...
		      - eCoeff00*LAT_rho(iEta,iXi) ...
		      - eCoeff10*LAT_rho(iEta+1,iXi) ...
		      - eCoeff01*LAT_rho(iEta,iXi+1) ...
		      - eCoeff11*LAT_rho(iEta+1,iXi+1);
	    end;
	  end;
	end;
      end;
    end;
  end;
  if (IsMatched == 1)
    nbAssigned=nbAssigned+1;
    ListETA(iNode,1)=iEtaSought;
    ListXI(iNode,1)=iXiSought;
    ListCoeff(iNode, 1)=eCoeff00;
    ListCoeff(iNode, 2)=eCoeff10;
    ListCoeff(iNode, 3)=eCoeff01;
    ListCoeff(iNode, 4)=eCoeff11;
    if (DiffLON > maxDiffLON)
      maxDiffLON=DiffLON;
    end;
    if (DiffLON < minDiffLON)
      minDiffLON=DiffLON;
    end;
    if (DiffLAT > maxDiffLAT)
      maxDiffLAT=DiffLAT;
    end;
    if (DiffLAT < minDiffLAT)
      minDiffLAT=DiffLAT;
    end;
  else
    nbNonAssigned=nbNonAssigned+1;
    ListETA(iNode,1)=-1;
    ListXI(iNode,1)=-1;
    ListCoeff(iNode, 1)=0;
    ListCoeff(iNode, 2)=0;
    ListCoeff(iNode, 3)=0;
    ListCoeff(iNode, 4)=0;
  end;
end;
DoPresentationResult=0;
if (DoPresentationResult == 1)
  disp(['minDiffLON=' num2str(minDiffLON)]);
  disp(['maxDiffLON=' num2str(maxDiffLON)]);
  disp(['minDiffLAT=' num2str(minDiffLAT)]);
  disp(['maxDiffLAT=' num2str(maxDiffLAT)]);
  disp(['nbAssigned=' num2str(nbAssigned) ...
	'   nbNonAssigned=' num2str(nbNonAssigned)]);
end;
