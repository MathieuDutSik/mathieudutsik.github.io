function [Usma, Vsma]=InterpolMemEff_R2R_3Duvfield(...
    TotalArray, ARVDbig, ARVDsma, Ubig, Vbig)
MSKbig_rho=TotalArray.MSKbig_rho;
DEPbig_rho=TotalArray.DEPbig_rho;
DEPbig_u=TotalArray.DEPbig_u;
DEPbig_v=TotalArray.DEPbig_v;
MSKbig_u=TotalArray.MSKbig_u;
MSKbig_v=TotalArray.MSKbig_v;
ANGbig_rho=TotalArray.ANGbig_rho;
MSKsma_rho=TotalArray.MSKsma_rho;
DEPsma_rho=TotalArray.DEPsma_rho;
DEPsma_u=TotalArray.DEPsma_u;
DEPsma_v=TotalArray.DEPsma_v;
MSKsma_u=TotalArray.MSKsma_u;
MSKsma_v=TotalArray.MSKsma_v;
ANGsma_rho=TotalArray.ANGsma_rho;
ANGsma_u_big=TotalArray.ANGsma_u_big;
ANGsma_v_big=TotalArray.ANGsma_v_big;
ListRelETA_uu=TotalArray.ListRelETA_uu;
ListRelXI_uu=TotalArray.ListRelXI_uu;
ListRelCoeff_uu=TotalArray.ListRelCoeff_uu;
ListRelETA_uv=TotalArray.ListRelETA_uv;
ListRelXI_uv=TotalArray.ListRelXI_uv;
ListRelCoeff_uv=TotalArray.ListRelCoeff_uv;
ListRelETA_vu=TotalArray.ListRelETA_vu;
ListRelXI_vu=TotalArray.ListRelXI_vu;
ListRelCoeff_vu=TotalArray.ListRelCoeff_vu;
ListRelETA_vv=TotalArray.ListRelETA_vv;
ListRelXI_vv=TotalArray.ListRelXI_vv;
ListRelCoeff_vv=TotalArray.ListRelCoeff_vv;
%
Nbig=ARVDbig.N;
Nsma=ARVDsma.N;
%
[eta_rho_big,xi_rho_big]=size(MSKbig_rho);
[eta_u_big,xi_u_big]=size(MSKbig_u);
[eta_v_big,xi_v_big]=size(MSKbig_v);
%
[NbigU1, eta_u_big1, xi_u_big1]=size(Ubig);
[NbigV1, eta_v_big1, xi_v_big1]=size(Vbig);
if (eta_u_big ~= eta_u_big1 || xi_u_big ~= xi_u_big1 || ...
    NbigU1 ~= Nbig)
  disp('size error between TotalArray.MSKbig_u and Ubig');
  error('Please correct');
end;
if (eta_v_big ~= eta_v_big1 || xi_v_big ~= xi_v_big1 || ...
    NbigV1 ~= Nbig)
  disp('size error between TotalArray.MSKbig_v and Vbig');
  error('Please correct');
end;
ANGbig_u=(ANGbig_rho(:, 1:xi_rho_big-1)+ANGbig_rho(:, 2:xi_rho_big))/2;
ANGbig_v=(ANGbig_rho(1:eta_rho_big-1, :)+ANGbig_rho(2:eta_rho_big, :))/2;
%DEPbig_u=(DEPbig_rho(:, 1:xi_rho_big-1)+DEPbig_rho(:, 2:xi_rho_big))/2;
%DEPbig_v=(DEPbig_rho(1:eta_rho_big-1, :)+DEPbig_rho(2:eta_rho_big, :))/2;
[BigZr_u, BigZw_u]=GetVerticalLevels2(DEPbig_u, MSKbig_u, ARVDbig);
[BigZr_v, BigZw_v]=GetVerticalLevels2(DEPbig_v, MSKbig_v, ARVDbig);
%
%
[eta_rho_sma,xi_rho_sma]=size(MSKsma_rho);
[eta_u_sma,xi_u_sma]=size(MSKsma_u);
[eta_v_sma,xi_v_sma]=size(MSKsma_v);
ANGsma_u=(ANGsma_rho(:, 1:xi_rho_sma-1)+ANGsma_rho(:, 2:xi_rho_sma))/2;
ANGsma_v=(ANGsma_rho(1:eta_rho_sma-1, :)+ANGsma_rho(2:eta_rho_sma, :))/2;
%DEPsma_u=(DEPsma_rho(:, 1:xi_rho_sma-1)+DEPsma_rho(:, 2:xi_rho_sma))/2;
%DEPsma_v=(DEPsma_rho(1:eta_rho_sma-1, :)+DEPsma_rho(2:eta_rho_sma, :))/2;
[SmaZr_u, SmaZw_u]=GetVerticalLevels2(DEPsma_u, MSKsma_u, ARVDsma);
[SmaZr_v, SmaZw_v]=GetVerticalLevels2(DEPsma_v, MSKsma_v, ARVDsma);
%
%
ListZ=zeros(4,1);
ListIDX=zeros(4,1);
Usma=zeros(Nsma, eta_u_sma,xi_u_sma);
for iEtaSma=1:eta_u_sma
  for iXiSma=1:xi_u_sma
    if (MSKsma_u(iEtaSma, iXiSma) == 1)
      deltaAng=ANGsma_u(iEtaSma, iXiSma)-...
	       ANGsma_u_big(iEtaSma, iXiSma);
      for iNsma=1:Nsma
	MyDep=SmaZr_u(iNsma,iEtaSma,iXiSma);
	if (isfinite(MyDep) == 1)
	  eSumU_u=0;
	  eSumWeight=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_uu(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_uu(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_uu(iEtaSma, iXiSma, idx);
	      Ku=find(isfinite(BigZr_u(:, iEtaBig, iXiBig)));
	      idxfind=min(Ku);
	      ListZ(idx,1)=BigZr_u(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_u(iNbig,iEtaBig,iXiBig);
		dep2=BigZr_u(iNbig+1,iEtaBig,iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep < dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  eSumU_u=eSumU_u+eWeight*alpha1*...
			  Ubig(iNbig, iEtaBig, iXiBig);
		  eSumU_u=eSumU_u+eWeight*alpha2*...
			  Ubig(iNbig+1, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 0)
		if (BigZr_u(Nbig,iEtaBig, iXiBig) <= MyDep)
		  test=1;
		  eSumU_u=eSumU_u+eWeight*Ubig(Nbig, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    U_u=eSumU_u/eSumWeight;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_uu(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_uu(iEtaSma, iXiSma, idxdep);
	    U_u=Ubig(iZlev, iEtaBig, iXiBig);
	  end;
	  %
	  eSumV_u=0;
	  eSumWeight=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_vu(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_vu(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_vu(iEtaSma, iXiSma, idx);
	      Kv=find(isfinite(BigZr_v(:, iEtaBig, iXiBig)));
	      idxfind=min(Kv);
	      ListZ(idx,1)=BigZr_v(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_v(iNbig, iEtaBig, iXiBig);
		dep2=BigZr_v(iNbig+1, iEtaBig, iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep < dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  eSumV_u=eSumV_u+eWeight*alpha1*...
			  Vbig(iNbig, iEtaBig, iXiBig);
		  eSumV_u=eSumV_u+eWeight*alpha2*...
			  Vbig(iNbig+1, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 0)
		if (BigZr_v(Nbig, iEtaBig, iXiBig) <= MyDep)
		  test=1;
		  eSumV_u=eSumV_u+eWeight*Vbig(Nbig, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    V_u=eSumV_u/eSumWeight;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_vu(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_vu(iEtaSma, iXiSma, idxdep);
	    V_u=Vbig(iZlev, iEtaBig, iXiBig);
	  end;
	  eUsma=U_u*cos(deltaAng)+V_u*sin(deltaAng);
%	  if (isnan(eUsma) == 1)
%	    disp('Please debug from here');
%	    keyboard;
%	  end;
	  Usma(iNsma, iEtaSma, iXiSma)=eUsma;
	end;
      end;
    end;
  end;
end;
Vsma=zeros(Nsma, eta_v_sma,xi_v_sma);
for iEtaSma=1:eta_v_sma
  for iXiSma=1:xi_v_sma
    if (MSKsma_v(iEtaSma, iXiSma) == 1)
      deltaAng=ANGsma_v(iEtaSma, iXiSma)-...
	       ANGsma_v_big(iEtaSma, iXiSma);
      for iNsma=1:Nsma
	eSumU_v=0;
	eSumWeight=0;
	MyDep=SmaZr_v(iNsma,iEtaSma,iXiSma);
	if (isfinite(MyDep) == 1)
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_uv(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_uv(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_uv(iEtaSma, iXiSma, idx);
	      Ku=find(isfinite(BigZr_u(:, iEtaBig, iXiBig)));
	      idxfind=min(Ku);
	      ListZ(idx,1)=BigZr_u(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_u(iNbig,iEtaBig,iXiBig);
		dep2=BigZr_u(iNbig+1,iEtaBig,iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep < dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  eSumU_v=eSumU_v+eWeight*alpha1*...
			  Ubig(iNbig, iEtaBig, iXiBig);
		  eSumU_v=eSumU_v+eWeight*alpha2*...
			  Ubig(iNbig+1, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 0)
		if (BigZr_u(Nbig,iEtaBig,iXiBig) <= MyDep)
		  test=1;
		  eSumU_v=eSumU_v+eWeight*Ubig(Nbig, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    U_v=eSumU_v/eSumWeight;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_uv(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_uv(iEtaSma, iXiSma, idxdep);
	    U_v=Ubig(iZlev, iEtaBig, iXiBig);
	  end;
	  %
	  eSumWeight=0;
	  eSumV_v=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_vv(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_vv(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_vv(iEtaSma, iXiSma, idx);
	      Kv=find(isfinite(BigZr_v(:, iEtaBig, iXiBig)));
	      idxfind=min(Kv);
	      ListZ(idx,1)=BigZr_v(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_v(iNbig, iEtaBig, iXiBig);
		dep2=BigZr_v(iNbig+1, iEtaBig, iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep < dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  eSumV_v=eSumV_v+eWeight*alpha1*...
			  Vbig(iNbig, iEtaBig, iXiBig);
		  eSumV_v=eSumV_v+eWeight*alpha2*...
			  Vbig(iNbig+1, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 0)
		if (BigZr_v(Nbig, iEtaBig, iXiBig) <= MyDep)
		  test=1;
		  eSumV_v=eSumV_v+eWeight*Vbig(Nbig, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    V_v=eSumV_v/eSumWeight;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_vv(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_vv(iEtaSma, iXiSma, idxdep);
	    V_v=Vbig(iZlev, iEtaBig, iXiBig);
	  end;
	  eVsma=-U_v*sin(deltaAng)+V_v*cos(deltaAng);
	  Vsma(iNsma, iEtaSma, iXiSma)=eVsma;
	end;
      end;
    end;
  end;
end;
