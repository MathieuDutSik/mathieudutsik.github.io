function NEST_CreateNetcdfBoundaryStruct(...
    ncBound, TheArr, nbTime, s_rho, TheRecord)
if (isfield(TheRecord, 'DoSouth') == 1)
  DoSouth=TheRecord.DoSouth;
else
  DoSouth=0;
end;
if (isfield(TheRecord, 'DoNorth') == 1)
  DoNorth=TheRecord.DoNorth;
else
  DoNorth=0;
end;
if (isfield(TheRecord, 'DoWest') == 1)
  DoWest=TheRecord.DoWest;
else
  DoWest=0;
end;
if (isfield(TheRecord, 'DoEast') == 1)
  DoEast=TheRecord.DoEast;
else
  DoEast=0;
end;
if (isfield(TheArr, 'eta_rho') == 1)
  eta_rho=TheArr.eta_rho;
else
  eta_rho=TheArr.eta_rho_sma;
end;
if (isfield(TheArr, 'xi_rho') == 1)
  xi_rho=TheArr.xi_rho;
else
  xi_rho=TheArr.xi_rho_sma;
end;
eta_u=eta_rho;
xi_u=xi_rho-1;
eta_v=eta_rho-1;
xi_v=xi_rho;

ncBound('eta_rho')=eta_rho;
ncBound('xi_rho')=xi_rho;
ncBound('eta_u')=eta_u;
ncBound('xi_u')=xi_u;
ncBound('eta_v')=eta_v;
ncBound('xi_v')=xi_v;
ncBound('zeta_time')=nbTime;
ncBound('v2d_time')=nbTime;
ncBound('v3d_time')=nbTime;
ncBound('temp_time')=nbTime;
ncBound('salt_time')=nbTime;
ncBound('ocean_time')=nbTime;
ncBound('s_rho')=s_rho;
ncBound('dateString')=19;
%
ncBound{'zeta_time'}=ncdouble('zeta_time');
ncBound{'v2d_time'}=ncdouble('v2d_time');
ncBound{'v3d_time'}=ncdouble('v3d_time');
ncBound{'temp_time'}=ncdouble('temp_time');
ncBound{'salt_time'}=ncdouble('salt_time');
ncBound{'ocean_time_str'}=ncchar('ocean_time', 'dateString');
%
if (DoEast == 1)
  ncBound{'zeta_east'}=ncfloat('zeta_time', 'eta_rho');
  ncBound{'temp_east'}=ncfloat('temp_time', 's_rho', 'eta_rho');
  ncBound{'salt_east'}=ncfloat('salt_time', 's_rho', 'eta_rho');
  ncBound{'ubar_east'}=ncfloat('v2d_time', 'eta_u');
  ncBound{'vbar_east'}=ncfloat('v2d_time', 'eta_v');
  ncBound{'u_east'}=ncfloat('v3d_time', 's_rho', 'eta_u');
  ncBound{'v_east'}=ncfloat('v3d_time', 's_rho', 'eta_v');
end;
if (DoWest == 1)
  ncBound{'zeta_west'}=ncfloat('zeta_time', 'eta_rho');
  ncBound{'temp_west'}=ncfloat('temp_time', 's_rho', 'eta_rho');
  ncBound{'salt_west'}=ncfloat('salt_time', 's_rho', 'eta_rho');
  ncBound{'ubar_west'}=ncfloat('v2d_time', 'eta_u');
  ncBound{'vbar_west'}=ncfloat('v2d_time', 'eta_v');
  ncBound{'u_west'}=ncfloat('v3d_time', 's_rho', 'eta_u');
  ncBound{'v_west'}=ncfloat('v3d_time', 's_rho', 'eta_v');
end;
if (DoNorth == 1)
  ncBound{'zeta_north'}=ncfloat('zeta_time', 'xi_rho');
  ncBound{'temp_north'}=ncfloat('temp_time', 's_rho', 'xi_rho');
  ncBound{'salt_north'}=ncfloat('salt_time', 's_rho', 'xi_rho');
  ncBound{'ubar_north'}=ncfloat('v2d_time', 'xi_u');
  ncBound{'vbar_north'}=ncfloat('v2d_time', 'xi_v');
  ncBound{'u_north'}=ncfloat('v3d_time', 's_rho', 'xi_u');
  ncBound{'v_north'}=ncfloat('v3d_time', 's_rho', 'xi_v');
end;
if (DoSouth == 1)
  ncBound{'zeta_south'}=ncfloat('zeta_time', 'xi_rho');
  ncBound{'temp_south'}=ncfloat('temp_time', 's_rho', 'xi_rho');
  ncBound{'salt_south'}=ncfloat('salt_time', 's_rho', 'xi_rho');
  ncBound{'ubar_south'}=ncfloat('v2d_time', 'xi_u');
  ncBound{'vbar_south'}=ncfloat('v2d_time', 'xi_v');
  ncBound{'u_south'}=ncfloat('v3d_time', 's_rho', 'xi_u');
  ncBound{'v_south'}=ncfloat('v3d_time', 's_rho', 'xi_v');
end;
