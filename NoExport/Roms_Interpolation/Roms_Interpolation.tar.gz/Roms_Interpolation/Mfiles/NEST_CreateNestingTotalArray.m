function NestingTotalArray=NEST_CreateNestingTotalArray(...
    GrdArrBig, GrdArrSma, RecordBound, ARVDbig, ARVDsma, UseSpMat)

[eta_rho_sma, xi_rho_sma]=size(GrdArrSma.LON_rho);
[eta_u_sma, xi_u_sma]=size(GrdArrSma.LON_u);
[eta_v_sma, xi_v_sma]=size(GrdArrSma.LON_v);

MSKsma_rho=GrdArrSma.MSK_rho;
MSKsma_rho(2:eta_rho_sma-1,2:xi_rho_sma-1)=0;
GrdArrSma.MSK_rho=MSKsma_rho;
%
MSKsma_u=GrdArrSma.MSK_u;
MSKsma_u(2:eta_u_sma-1,2:xi_u_sma-1)=0;
GrdArrSma.MSK_u=MSKsma_u;
%
MSKsma_v=GrdArrSma.MSK_v;
MSKsma_v(2:eta_v_sma-1,2:xi_v_sma-1)=0;
GrdArrSma.MSK_v=MSKsma_v;
%
NestingTotalArray=InterpolGetTotalArray_R2R_fields_kernel(...
    GrdArrBig, GrdArrSma);
%
NestingTotalArray.GrdArrBig=GrdArrBig;
%
if (UseSpMat == 1)
  ArrayBigSma2D=InterpolGetSpMat_R2R_2Dfield(NestingTotalArray);
  ArrayBigSma2Duv=InterpolGetSpMat_R2R_2Duvfield(NestingTotalArray);
  ArrayBigSma3D=InterpolGetSpMat_R2R_3Dfield(...
      NestingTotalArray, ARVDbig, ARVDsma);
  ArrayBigSma3Duv=InterpolGetSpMat_R2R_3Duvfield(...
      NestingTotalArray, ARVDbig, ARVDsma);
  NestingTotalArray.ArrayBigSma2D=ArrayBigSma2D;
  NestingTotalArray.ArrayBigSma2Duv=ArrayBigSma2Duv;
  NestingTotalArray.ArrayBigSma3D=ArrayBigSma3D;
  NestingTotalArray.ArrayBigSma3Duv=ArrayBigSma3Duv;
end;
%
NestingTotalArray.RecordBound=RecordBound;
NestingTotalArray.ARVDbig=ARVDbig;
NestingTotalArray.ARVDsma=ARVDsma;
NestingTotalArray.UseSpMat=UseSpMat;
