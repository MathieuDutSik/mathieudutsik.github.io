function TotalArray=ADCP_R2A_GetTotalArray(...
    GrdArr, ARVD, ...
    ListLonADCP, ListLatADCP, ADCPverticalLevels)
%
% ---GrdArr is the ROMS grid array
% ---ARVD is the description of the vertical
%    discretization
%    ARVD.ThetaS
%    ARVD.ThetaB
%    ARVD.N
%    ARVD.hc
%    ARVD.Vtransform
%    ARVD.Vstretching
% ---ListLonADCP, ListLatADCP are arrays of ADCP in the format
%    real(nbADCP, 1)
% ---ADCPverticalLevels is a matrix of depth of the form
%    real(nbADCP, nbVertical)
%    if no depth is available (numbr of levels can vary from
%    one ADCP to another, then please put NaN)
%    for every ADCP/CTD this vector of depth should be increasing
%    or decreasing.

LON_rho=GrdArr.LON_rho;
LAT_rho=GrdArr.LAT_rho;
LON_u=GrdArr.LON_u;
LAT_u=GrdArr.LAT_u;
LON_v=GrdArr.LON_v;
LAT_v=GrdArr.LAT_v;
MSK_rho=GrdArr.MSK_rho;
MSK_u=GrdArr.MSK_u;
MSK_v=GrdArr.MSK_v;
DEP_rho=GrdArr.DEP_rho;
ANG_rho=GrdArr.ANG_rho;

[eta_u, xi_u]=size(LON_u);
[eta_v, xi_v]=size(LON_v);

nbADCP=size(ListLonADCP, 1);
if (size(ADCPverticalLevels, 1) ~= nbADCP || ...
    size(ListLatADCP,1) ~= nbADCP)
  disp('The matrix ListLon, ListLat, ADCPverticalLevels');
  disp('do not respect the prescribed sizes, which are:');
  disp('  ListLon(nbADCP,1)');
  disp('  ListLat(nbADCP,1)');
  disp('  ADCPverticalLevels(nbADCP, MaxNbLevel)');
  error('Please correct');
end;
ListMsk=ones(nbADCP, 1);

[eta_rho, xi_rho]=size(DEP_rho);
DEP_u=(DEP_rho(:, 1:xi_rho-1)+DEP_rho(:, 2:xi_rho))/2;
DEP_v=(DEP_rho(1:eta_rho-1, :)+DEP_rho(2:eta_rho, :))/2;


[Z_rU, Z_wU]=GetVerticalLevels2(DEP_u, MSK_u, ARVD);
[Z_rV, Z_wV]=GetVerticalLevels2(DEP_v, MSK_v, ARVD);
[Z_rRho, Z_wRho]=GetVerticalLevels2(DEP_rho, MSK_rho, ARVD);

TheRecU=Interpol_R2R_FindCoefficient2Dgrid(...
    LON_u, LAT_u, MSK_u, ...
    ListLonADCP, ListLatADCP, ListMsk);
TheRecV=Interpol_R2R_FindCoefficient2Dgrid(...
    LON_v, LAT_v, MSK_v, ...
    ListLonADCP, ListLatADCP, ListMsk);
TheRecR=Interpol_R2R_FindCoefficient2Dgrid(...
    LON_rho, LAT_rho, MSK_rho, ...
    ListLonADCP, ListLatADCP, ListMsk);

KusedR=find(TheRecR.MSKused == 1);
KusedU=find(TheRecU.MSKused == 1);
KusedV=find(TheRecV.MSKused == 1);
ListAng=zeros(nbADCP, 1);
for iADCP=1:nbADCP
  eSum=0;
  eSumWeight=0;
  for idx=1:4
    eWeight=TheRecR.ListRelCoeff(iADCP, 1, idx);
    if (eWeight > 0)
      iEta=TheRecR.ListRelETA(iADCP, 1, idx);
      iXi=TheRecR.ListRelXI(iADCP, 1, idx);
      if (TheRecR.MSKused(iEta,iXi) == 0)
	disp('Inconsistency here');
	keyboard;
	error('Please correct');
      end;
      eSum=eSum+ANG_rho(iEta, iXi)*eWeight;
      eSumWeight=eSumWeight+eWeight;
    end;
  end;
  ListAng(iADCP,1)=eSum/eSumWeight;
end;
clear('TotalArray');
TotalArray.nbADCP=nbADCP;
TotalArray.ListRelETA_u=TheRecU.ListRelETA;
TotalArray.ListRelXI_u=TheRecU.ListRelXI;
TotalArray.ListRelCoeff_u=TheRecU.ListRelCoeff;
%
TotalArray.ListRelETA_v=TheRecV.ListRelETA;
TotalArray.ListRelXI_v=TheRecV.ListRelXI;
TotalArray.ListRelCoeff_v=TheRecV.ListRelCoeff;
%
TotalArray.ListRelETA_rho=TheRecR.ListRelETA;
TotalArray.ListRelXI_rho=TheRecR.ListRelXI;
TotalArray.ListRelCoeff_rho=TheRecR.ListRelCoeff;
TotalArray.KusedR=KusedR;
TotalArray.KusedU=KusedU;
TotalArray.KusedV=KusedV;
%
TotalArray.ListAng=ListAng;
TotalArray.DEPbig_rho=DEP_rho;
TotalArray.DEPbig_u=DEP_u;
TotalArray.DEPbig_v=DEP_v;
TotalArray.BigZ_rU=Z_rU;
TotalArray.BigZ_rV=Z_rV;
TotalArray.BigZ_rRho=Z_rRho;
%
TotalArray.ARVD=ARVD;
TotalArray.ADCPverticalLevels=ADCPverticalLevels;
