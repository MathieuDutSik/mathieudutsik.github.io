function [eTimeDay, eTimeSec]=GetCorrectTime(eTime)

%disp(['Call with eTime=' num2str(eTime)]);
Day2sec=24*3600;
if (eTime > 10^30)
  eTimeDay=eTime;
  eTimeSec=eTime;
else
  if (eTime > 1000000)
    [eTimeDay, eTimeSec]=GetCorrectTime(eTime/Day2sec);
  else
    eTimeDay=eTime;
    eTimeSec=eTime*Day2sec;
  end;
end;
%disp(['eTimeDay=' num2str(eTimeDay) ...
%      ' eTimeSec=' num2str(eTimeSec)]);
      
