function eMjd=DATE_ConvertRomsRefNetcdf(strUnit)
Lrec=SplitLine(strUnit, ' ');
strYear=Lrec{3}(1:4);
strMonth=Lrec{3}(6:7);
strDay=Lrec{3}(9:10);
if (size(Lrec,2) == 4)
  strHour=Lrec{4}(1:2);
  strMin=Lrec{4}(4:5);
  strSec=Lrec{4}(7:8);
else
  strHour='00';
  strMin ='00';
  strSec ='00';
end;
eYear=str2num(strYear);
eMonth=str2num(strMonth);
eDay=str2num(strDay);
eHour=str2num(strHour);
eMin=str2num(strMin);
eSec=str2num(strSec);
eMjd=DATE_ConvertSix2mjd(...
    eYear, eMonth, eDay, eHour, eMin, eSec);
