function eMult=DATE_GetCFtimeMult_ForSec(eStr)

len=size(eStr,2);
H=SplitLine(eStr, ' ');
if (UTIL_IsStringEqual(H{1}, 'days') == 1)
  eMult=86400;
elseif (UTIL_IsStringEqual(H{1}, 'day') == 1)
  eMult=86400;
elseif (UTIL_IsStringEqual(H{1}, 'hours') == 1)
  eMult=3600;
elseif (UTIL_IsStringEqual(H{1}, 'hour') == 1)
  eMult=3600;
elseif (UTIL_IsStringEqual(H{1}, 'seconds') == 1)
  eMult=1;
elseif (UTIL_IsStringEqual(H{1}, 'second') == 1)
  eMult=1;
else
  disp('Please put your code here. Seems weird');
  error('Please correct');
end;
