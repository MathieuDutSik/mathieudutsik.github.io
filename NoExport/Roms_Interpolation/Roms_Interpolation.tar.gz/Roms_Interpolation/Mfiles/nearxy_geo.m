function [TheIdx, TheDist]=nearxy_geo(LON, LAT, eLon, eLat)

LONexp=LON(:);
LATexp=LAT(:);
nbPt=size(LONexp, 1);
TheDist=2000;
for iPt=1:nbPt
  dist=GeodesicDistance_V2(LONexp(iPt, 1), LATexp(iPt, 1), eLon, eLat);
  if (dist < TheDist)
    TheIdx=iPt;
    TheDist=dist;
  end;
end;
