function TheRecordInterp=InterpolSquareGrid2SquareGrid(...
    LON1, LAT1, LON2, LAT2)
%
% (LON1, LAT1) and (LON2, LAT2) are assumed to come from
% an almost square grid curvilinear if necessary.
% 
% We return two arrays MAT_L and MAT_M in TheRecordInterp
% of size (L1, M1) that contains the nearest pair in (LON2, LAT2)
% it also returns GeodesicDistance, which is the nearest point
% in radian.
% 
% We return the list of indexes of nearest point done according
% to a Graver heuristic.

GraverOption=2;
if (GraverOption == 1)
  GraverBasis=[1 0;
	       0 1;
	       -1 0;
	       0 -1];
elseif (GraverOption == 2)
  GraverBasis=[1 0;
	       0 1;
	       -1 0;
	       0 -1;
	       1 -1;
	       -1 -1;
	       1 1;
	       -1 1];
elseif (GraverOption == 3)
  GraverBasis=zeros(0,2);
  nVal=2;
  idx=0;
  for i=-nVal:nVal
    for j=-nVal:nVal
      idx=idx+1;
      GraverBasis(idx,1)=i;
      GraverBasis(idx,2)=j;
    end;
  end;
else
  disp('Please make an accepted choice');
  error('Please correct');
end;
nbGraver=size(GraverBasis, 1);
%disp(['nbGraver=' num2str(nbGraver)]);
[L1, M1]=size(LON1);
[L2, M2]=size(LON2);
CoordMat12_L=zeros(L1, M1);
CoordMat12_M=zeros(L1, M1);
GeodesicDistanceMatrix=zeros(L1, M1);
%disp(['L1=', num2str(L1) '  M1=' num2str(M1)]);
for iL=1:L1
  for jM=1:M1
    eLonSearch=LON1(iL, jM);
    eLatSearch=LAT1(iL, jM);
    if (iL == 1 && jM == 1)
      iCoordL=1;
      jCoordM=1;
    elseif (jM == 1)
      iCoordL=CoordMat12_L(iL-1, jM);
      jCoordM=CoordMat12_M(iL-1, jM);
    else
      iCoordL=CoordMat12_L(iL, jM-1);
      jCoordM=CoordMat12_M(iL, jM-1);
    end;
    eLonPrev=LON2(iCoordL, jCoordM);
    eLatPrev=LAT2(iCoordL, jCoordM);
    FoundDist=GeodesicDistance_V2(...
	eLonPrev, eLatPrev, eLonSearch, eLatSearch);
    while(1)
      IsFinished=1;
      for iGraver=1:nbGraver
	iNew=iCoordL+GraverBasis(iGraver,1);
	jNew=jCoordM+GraverBasis(iGraver,2);
	if (iNew > 0 && iNew < L2+1 && ...
	    jNew > 0 && jNew < M2+1)
	  eLon=LON2(iNew, jNew);
	  eLat=LAT2(iNew, jNew);
	  dist=GeodesicDistance_V2(...
	      eLon, eLat, eLonSearch, eLatSearch);
	  if (dist < FoundDist)
%	    disp(['dist=' num2str(dist) ...
%		  '  FoundDist=' num2str(FoundDist)]);
	    iCoordL=iNew;
	    jCoordM=jNew;
	    IsFinished=0;
	    FoundDist=dist;
	  end;
	end;
      end;
      if (IsFinished == 1)
	break;
      end;
    end;
    CoordMat12_L(iL, jM)=iCoordL;
    CoordMat12_M(iL, jM)=jCoordM;
    GeodesicDistanceMatrix(iL, jM)=FoundDist;
  end;
end;
EarthRadius=6370;
TheDistMatrixKM=EarthRadius*GeodesicDistanceMatrix;
TheRecordInterp.MAT_L=CoordMat12_L;
TheRecordInterp.MAT_M=CoordMat12_M;
TheRecordInterp.GeodesicDistance=GeodesicDistanceMatrix;
TheRecordInterp.DistMatrixKM=TheDistMatrixKM;
