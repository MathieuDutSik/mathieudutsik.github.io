function TheRec=Interpol_FindCoefficient2DgridKernel(...
    LON_rho, LAT_rho, MSK_rho, ...
    ListLON, ListLAT, ...
    ListETA, ListXI, ListCoeff)

Ksea=find(MSK_rho == 1);
[eta_rho, xi_rho]=size(MSK_rho);
[ETAmat, XImat]=Interpol_GetETAXImat(...
    eta_rho, xi_rho);
LON_rho_Sel=LON_rho(Ksea);
LAT_rho_Sel=LAT_rho(Ksea);
ETAmat_Sel=ETAmat(Ksea);
XImat_Sel=XImat(Ksea);

nbNode=size(ListLON, 1);

ListBlock=[0 0;
	   1 0;
	   0 1;
	   1 1];
MSKused=zeros(eta_rho, xi_rho);
ListRelETA=zeros(nbNode,4);
ListRelXI=zeros(nbNode,4);
ListRelCoeff=zeros(nbNode,4);
ListRelIDX=zeros(nbNode,1);
nbHard=0;
nbEasy=0;
nbTotal=nbNode;

for iNode=1:nbNode
  eLonSma=ListLON(iNode,1);
  eLatSma=ListLAT(iNode,1);
  iEtaBig=ListETA(iNode,1);
  iXiBig=ListXI(iNode,1);
  idx=0;
  if (iEtaBig ~= -1 && iXiBig ~= -1)
    eSumWeight=0;
    for iblock=1:4
      iEtaN=iEtaBig+ListBlock(iblock,1);
      iXiN=iXiBig+ListBlock(iblock,2);
      if (MSK_rho(iEtaN, iXiN) == 1)
	idx=idx+1;
	eWeight=ListCoeff(iNode, iblock);
	ListRelETA(iNode, idx)=iEtaN;
	ListRelXI(iNode, idx)=iXiN;
	MSKused(iEtaN, iXiN)=1;
	ListRelCoeff(iNode, idx)=eWeight;
	eSumWeight=eSumWeight+eWeight;
      end;
    end;
    if (eSumWeight > 0)
      for i=1:idx
	ListRelCoeff(iNode, i)=...
	    ListRelCoeff(iNode, i)/eSumWeight;
      end;
      DoDebug=0;
      if (DoDebug == 1)
	DiffLON=eLonSma;
	DiffLAT=eLatSma;
	for i=1:idx
	  iEta=ListRelETA(iNode,i);
	  iXi=ListRelXI(iNode,i);
	  DiffLON=DiffLON - ListRelCoeff(iNode,i)*LON_rho(iEta,iXi);
	  DiffLAT=DiffLAT - ListRelCoeff(iNode,i)*LAT_rho(iEta,iXi);
	end;
	if (abs(DiffLON) > 0.01 || abs(DiffLAT) > 0.01)
	  disp(['iNode=' num2str(iNode) ' i=', num2str(i)]);
	  disp(['eLonSma=' num2str(eLonSma) ...
		' eLatSma=' num2str(eLatSma)]);
	  disp(['DiffLON=' num2str(DiffLON) ...
		'  DiffLAT=' num2str(DiffLAT)]);
	end;
      end;
    else
      idx=0;
    end;
  end;
  if (idx == 0)
    nbHard=nbHard+1;
    [TheIdx, TheDist]=nearxy_geo_V2(...
	LON_rho_Sel, LAT_rho_Sel, eLonSma, eLatSma);
    iEtaBig=ETAmat_Sel(TheIdx,1);
    iXiBig=XImat_Sel(TheIdx,1);
    ListRelETA(iNode, 1)=iEtaBig;
    ListRelXI(iNode, 1)=iXiBig;
    MSKused(iEtaBig, iXiBig)=1;
    ListRelCoeff(iNode, 1)=1;
    idx=1;
  else
    nbEasy=nbEasy+1;
  end;
  ListRelIDX(iNode,1)=idx;
end;
nbTotalWet=nbHard+nbEasy;
%disp(['nbHard=' num2str(nbHard) '  nbEasy=' num2str(nbEasy)]);
%disp(['nbTotalWet=' num2str(nbTotalWet) ' nbTotal=' num2str(nbTotal)]);

sizSpMat=sum(ListRelIDX);
iList=zeros(sizSpMat,1);
jList=zeros(sizSpMat,1);
sList=zeros(sizSpMat,1);
CorrespMat=GetCorrespMatrix(2, [eta_rho; xi_rho]);
idxspm=0;
for iNode=1:nbNode
  idx=ListRelIDX(iNode,1);
  for j=1:idx
    iEta=ListRelETA(iNode,j);
    iXi=ListRelXI(iNode,j);
    iPoint=CorrespMat(iEta, iXi);
    idxspm=idxspm+1;
    iList(idxspm,1)=iNode;
    jList(idxspm,1)=iPoint;
    sList(idxspm,1)=ListRelCoeff(iNode,j);
  end;
end;
nbPtTarget=eta_rho*xi_rho;
SPmat=sparse(iList, jList, sList, nbNode, nbPtTarget);
%
TheRec.ListRelETA=ListRelETA;
TheRec.ListRelXI=ListRelXI;
TheRec.ListRelCoeff=ListRelCoeff;
TheRec.ListRelIDX=ListRelIDX;
TheRec.MSKused=MSKused;
TheRec.SPmat=SPmat;
