function NewState=Interpol_R2R_AllFields(TotalArray, OldState)
%
% NewState=InterpolMemEff_R2R_AllFields(TotalArray, ARVDbig, ARVDsma, OldState)
%   NewState and OldState contains ZETA, UBAR, VBAR, TEMP, SALT, U, V
%   and they are interpolated from the big grid to the small one
%   according to the TotalArray interpolation fields and the
%   ARVDbig, ARVDsma vertical discretization
%
if (TotalArray.UseSpMat == 0)
%  disp('Before doing the MemEff interpolations');
  ZETAsma=InterpolMemEff_R2R_2Dfield(TotalArray, OldState.ZETA);
  [UBARsma, VBARsma]=InterpolMemEff_R2R_2Duvfield(...
      TotalArray, OldState.UBAR, OldState.VBAR);
  TEMPsma=InterpolMemEff_R2R_3Dfield(...
      TotalArray, TotalArray.ARVDbig, TotalArray.ARVDsma, ...
      OldState.TEMP);
  SALTsma=InterpolMemEff_R2R_3Dfield(...
      TotalArray, TotalArray.ARVDbig, TotalArray.ARVDsma, OldState.SALT);
  [Usma, Vsma]=InterpolMemEff_R2R_3Duvfield(...
      TotalArray, TotalArray.ARVDbig, TotalArray.ARVDsma, ...
      OldState.U, OldState.V);
%  disp('After doing the MemEff interpolations');
else
%  disp('Before doing the SpMat interpolations');
  ZETAsma=InterpolSpMat_R2R_2Dfield(...
      TotalArray.ArrayBigSma2D, OldState.ZETA);
  [UBARsma, VBARsma]=InterpolSpMat_R2R_2Duvfield(...
      TotalArray.ArrayBigSma2Duv, OldState.UBAR, OldState.VBAR);
  TEMPsma=InterpolSpMat_R2R_3Dfield(...
      TotalArray.ArrayBigSma3D, OldState.TEMP);
  SALTsma=InterpolSpMat_R2R_3Dfield(...
      TotalArray.ArrayBigSma3D, OldState.SALT);
  [Usma, Vsma]=InterpolSpMat_R2R_3Duvfield(...
      TotalArray.ArrayBigSma3Duv, OldState.U, OldState.V);
%  disp('After doing the SpMat interpolations');
end;
NewState.ZETA=ZETAsma;
NewState.TEMP=TEMPsma;
NewState.SALT=SALTsma;
NewState.UBAR=UBARsma;
NewState.VBAR=VBARsma;
NewState.U=Usma;
NewState.V=Vsma;
NewState.eTime=OldState.eTime;
