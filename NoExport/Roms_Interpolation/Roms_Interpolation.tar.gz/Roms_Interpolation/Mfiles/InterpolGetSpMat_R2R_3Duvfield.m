function ArrayBigSma3Duv=InterpolGetSpMat_R2R_3Duvfield(...
    TotalArray, ARVDbig, ARVDsma)
MSKbig_rho=TotalArray.MSKbig_rho;
DEPbig_rho=TotalArray.DEPbig_rho;
DEPbig_u=TotalArray.DEPbig_u;
DEPbig_v=TotalArray.DEPbig_v;
MSKbig_u=TotalArray.MSKbig_u;
MSKbig_v=TotalArray.MSKbig_v;
ANGbig_rho=TotalArray.ANGbig_rho;
MSKsma_rho=TotalArray.MSKsma_rho;
DEPsma_rho=TotalArray.DEPsma_rho;
DEPsma_u=TotalArray.DEPsma_u;
DEPsma_v=TotalArray.DEPsma_v;
MSKsma_u=TotalArray.MSKsma_u;
MSKsma_v=TotalArray.MSKsma_v;
ANGsma_rho=TotalArray.ANGsma_rho;
ANGsma_u_big=TotalArray.ANGsma_u_big;
ANGsma_v_big=TotalArray.ANGsma_v_big;
Nbig=ARVDbig.N;
Nsma=ARVDsma.N;
ListRelETA_uu=TotalArray.ListRelETA_uu;
ListRelXI_uu=TotalArray.ListRelXI_uu;
ListRelCoeff_uu=TotalArray.ListRelCoeff_uu;
ListRelETA_uv=TotalArray.ListRelETA_uv;
ListRelXI_uv=TotalArray.ListRelXI_uv;
ListRelCoeff_uv=TotalArray.ListRelCoeff_uv;
ListRelETA_vu=TotalArray.ListRelETA_vu;
ListRelXI_vu=TotalArray.ListRelXI_vu;
ListRelCoeff_vu=TotalArray.ListRelCoeff_vu;
ListRelETA_vv=TotalArray.ListRelETA_vv;
ListRelXI_vv=TotalArray.ListRelXI_vv;
ListRelCoeff_vv=TotalArray.ListRelCoeff_vv;
disp('Computing sparse matrix for 2D + 1D UV-field interpolation');
%
[eta_rho_big,xi_rho_big]=size(MSKbig_rho);
[eta_u_big,xi_u_big]=size(MSKbig_u);
[eta_v_big,xi_v_big]=size(MSKbig_v);
ANGbig_u=(ANGbig_rho(:, 1:xi_rho_big-1)+ANGbig_rho(:, 2:xi_rho_big))/2;
ANGbig_v=(ANGbig_rho(1:eta_rho_big-1, :)+ANGbig_rho(2:eta_rho_big, :))/2;
%DEPbig_u=(DEPbig_rho(:, 1:xi_rho_big-1)+DEPbig_rho(:, 2:xi_rho_big))/2;
%DEPbig_v=(DEPbig_rho(1:eta_rho_big-1, :)+DEPbig_rho(2:eta_rho_big, :))/2;
[BigZr_u, BigZw_u]=GetVerticalLevels2(DEPbig_u, MSKbig_u, ARVDbig);
[BigZr_v, BigZw_v]=GetVerticalLevels2(DEPbig_v, MSKbig_v, ARVDbig);
CorrespMatBig_u=GetCorrespMatrix(3, [Nbig; eta_u_big; xi_u_big]);
CorrespMatBig_v=GetCorrespMatrix(3, [Nbig; eta_v_big; xi_v_big]);
SIZ_u_big=eta_u_big*xi_u_big*Nbig;
SIZ_v_big=eta_v_big*xi_v_big*Nbig;
SIZ_big=SIZ_u_big+SIZ_v_big;
%
%
[eta_rho_sma,xi_rho_sma]=size(MSKsma_rho);
[eta_u_sma,xi_u_sma]=size(MSKsma_u);
[eta_v_sma,xi_v_sma]=size(MSKsma_v);
ANGsma_u=(ANGsma_rho(:, 1:xi_rho_sma-1)+ANGsma_rho(:, 2:xi_rho_sma))/2;
ANGsma_v=(ANGsma_rho(1:eta_rho_sma-1, :)+ANGsma_rho(2:eta_rho_sma, :))/2;
%DEPsma_u=(DEPsma_rho(:, 1:xi_rho_sma-1)+DEPsma_rho(:, 2:xi_rho_sma))/2;
%DEPsma_v=(DEPsma_rho(1:eta_rho_sma-1, :)+DEPsma_rho(2:eta_rho_sma, :))/2;
[SmaZr_u, SmaZw_u]=GetVerticalLevels2(DEPsma_u, MSKsma_u, ARVDsma);
[SmaZr_v, SmaZw_v]=GetVerticalLevels2(DEPsma_v, MSKsma_v, ARVDsma);
CorrespMatSma_u=GetCorrespMatrix(3, [Nsma; eta_u_sma; xi_u_sma]);
CorrespMatSma_v=GetCorrespMatrix(3, [Nsma; eta_v_sma; xi_v_sma]);
SIZ_u_sma=eta_u_sma*xi_u_sma*Nsma;
SIZ_v_sma=eta_v_sma*xi_v_sma*Nsma;
SIZ_sma=SIZ_u_sma+SIZ_v_sma;
%
KseaUsma=find(MSKsma_u == 1);
nbWetUsma=size(KseaUsma,1);
KseaVsma=find(MSKsma_v == 1);
nbWetVsma=size(KseaVsma,1);
UpperEstPoint=nbWetUsma*16*Nsma+nbWetVsma*16*Nsma;
iList=zeros(UpperEstPoint, 1);
jList=zeros(UpperEstPoint, 1);
sList=zeros(UpperEstPoint, 1);
idxspm=0;
%
ListZ=zeros(4,1);
iListU_u=zeros(8,1);
jListU_u=zeros(8,1);
sListU_u=zeros(8,1);
iListV_u=zeros(8,1);
jListV_u=zeros(8,1);
sListV_u=zeros(8,1);
iListU_v=zeros(8,1);
jListU_v=zeros(8,1);
sListU_v=zeros(8,1);
iListV_v=zeros(8,1);
jListV_v=zeros(8,1);
sListV_v=zeros(8,1);
disp(['eta_u_sma=' num2str(eta_u_sma) ...
      ' xi_u_sma=' num2str(xi_u_sma)]);
for iEtaSma=1:eta_u_sma
  for iXiSma=1:xi_u_sma
    if (MSKsma_u(iEtaSma, iXiSma) == 1)
      deltaAng=ANGsma_u(iEtaSma, iXiSma)-...
	       ANGsma_u_big(iEtaSma, iXiSma);
      for iNsma=1:Nsma
	idxSma_u=CorrespMatSma_u(iNsma, iEtaSma, iXiSma);
	eSumWeight=0;
	MyDep=SmaZr_u(iNsma,iEtaSma,iXiSma);
	if (isfinite(MyDep) == 1)
	  nbU_u=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_uu(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_uu(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_uu(iEtaSma, iXiSma, idx);
	      Ku=find(isfinite(BigZr_u(:, iEtaBig, iXiBig)));
	      idxfind=min(Ku);
	      ListZ(idx,1)=BigZr_u(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_u(iNbig, iEtaBig, iXiBig);
		dep2=BigZr_u(iNbig+1, iEtaBig, iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep <= dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  idxbig1=CorrespMatBig_u(iNbig, iEtaBig, iXiBig);
		  idxbig2=CorrespMatBig_u(iNbig+1, iEtaBig, iXiBig);
		  nbU_u=nbU_u+1;
		  iListU_u(nbU_u,1)=idxSma_u;
		  jListU_u(nbU_u,1)=idxbig1;
		  sListU_u(nbU_u,1)=eWeight*alpha1;
		  nbU_u=nbU_u+1;
		  iListU_u(nbU_u,1)=idxSma_u;
		  jListU_u(nbU_u,1)=idxbig2;
		  sListU_u(nbU_u,1)=eWeight*alpha2;
		end;
	      end;
	      if (test == 0)
		if (BigZr_u(Nbig,iEtaBig,iXiBig) <= MyDep)
		  test=1;
		  idxbig=CorrespMatBig_u(Nbig, iEtaBig, iXiBig);
		  nbU_u=nbU_u+1;
		  iListU_u(nbU_u,1)=idxSma_u;
		  jListU_u(nbU_u,1)=idxbig;
		  sListU_u(nbU_u,1)=eWeight;
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    for i=1:nbU_u
	      sListU_u(i,1)=sListU_u(i,1)/eSumWeight;
	    end;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_uu(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_uu(iEtaSma, iXiSma, idxdep);
	    idxbig=CorrespMatBig_u(iZlev, iEtaBig, iXiBig);
	    nbU_u=nbU_u+1;
	    iListU_u(nbU_u,1)=idxSma_u;
	    jListU_u(nbU_u,1)=idxbig;
	    sListU_u(nbU_u,1)=1;
	  end;
	  %
	  eSumWeight=0;
	  nbV_u=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_vu(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_vu(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_vu(iEtaSma, iXiSma, idx);
	      Kv=find(isfinite(BigZr_v(:, iEtaBig, iXiBig)));
	      idxfind=min(Kv);
	      ListZ(idx,1)=BigZr_v(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_v(iNbig, iEtaBig, iXiBig);
		dep2=BigZr_v(iNbig+1, iEtaBig, iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep <= dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  idxbig1=CorrespMatBig_v(iNbig, iEtaBig, iXiBig);
		  idxbig2=CorrespMatBig_v(iNbig+1, iEtaBig, iXiBig);
		  nbV_u=nbV_u+1;
		  iListV_u(nbV_u,1)=idxSma_u;
		  jListV_u(nbV_u,1)=SIZ_u_big+idxbig1;
		  sListV_u(nbV_u,1)=eWeight*alpha1;
		  nbV_u=nbV_u+1;
		  iListV_u(nbV_u,1)=idxSma_u;
		  jListV_u(nbV_u,1)=SIZ_u_big+idxbig2;
		  sListV_u(nbV_u,1)=eWeight*alpha2;
		end;
	      end;
	      if (test == 0)
		if (BigZr_v(Nbig,iEtaBig,iXiBig) <= MyDep)
		  test=1;
		  idxbig=CorrespMatBig_v(Nbig, iEtaBig, iXiBig);
		  nbV_u=nbV_u+1;
		  iListV_u(nbV_u,1)=idxSma_u;
		  jListV_u(nbV_u,1)=SIZ_u_big+idxbig;
		  sListV_u(nbV_u,1)=eWeight;
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    for i=1:nbV_u
	      sListV_u(i,1)=sListV_u(i,1)/eSumWeight;
	    end;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_vu(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_vu(iEtaSma, iXiSma, idxdep);
	    idxbig=CorrespMatBig_v(iZlev, iEtaBig, iXiBig);
	    nbV_u=nbV_u+1;
	    iListV_u(nbV_u,1)=idxSma_u;
	    jListV_u(nbV_u,1)=SIZ_u_big+idxbig;
	    sListV_u(nbV_u,1)=1;
	  end;
	  for i=1:nbU_u
	    idxspm=idxspm+1;
	    iList(idxspm,1)=iListU_u(i,1);
	    jList(idxspm,1)=jListU_u(i,1);
	    sList(idxspm,1)=sListU_u(i,1)*cos(deltaAng);
	  end;
	  for i=1:nbV_u
	    idxspm=idxspm+1;
	    iList(idxspm,1)=iListV_u(i,1);
	    jList(idxspm,1)=jListV_u(i,1);
	    sList(idxspm,1)=sListV_u(i,1)*sin(deltaAng);
	  end;
	end;
      end;
    end;
  end;
end;
for iEtaSma=1:eta_v_sma
  for iXiSma=1:xi_v_sma
    if (MSKsma_v(iEtaSma, iXiSma) == 1)
      deltaAng=ANGsma_v(iEtaSma, iXiSma)-...
	       ANGsma_v_big(iEtaSma, iXiSma);
      for iNsma=1:Nsma
	idxSma_v=CorrespMatSma_v(iNsma, iEtaSma, iXiSma);
	MyDep=SmaZr_v(iNsma, iEtaSma, iXiSma);
	if (isfinite(MyDep) == 1)
	  eSumWeight=0;
	  nbU_v=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_uv(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_uv(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_uv(iEtaSma, iXiSma, idx);
	      Ku=find(isfinite(BigZr_u(:, iEtaBig, iXiBig)));
	      idxfind=min(Ku);
	      ListZ(idx,1)=BigZr_u(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_u(iNbig, iEtaSma, iXiBig);
		dep2=BigZr_u(iNbig+1, iEtaSma, iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep <= dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  idxbig1=CorrespMatBig_u(iNbig, iEtaBig, iXiBig);
		  idxbig2=CorrespMatBig_u(iNbig+1, iEtaBig, iXiBig);
		  nbU_v=nbU_v+1;
		  iListU_v(nbU_v,1)=SIZ_u_sma+idxSma_v;
		  jListU_v(nbU_v,1)=idxbig1;
		  sListU_v(nbU_v,1)=eWeight*alpha1;
		  nbU_v=nbU_v+1;
		  iListU_v(nbU_v,1)=SIZ_u_sma+idxSma_v;
		  jListU_v(nbU_v,1)=idxbig2;
		  sListU_v(nbU_v,1)=eWeight*alpha2;
		end;
	      end;
	      if (test == 0)
		if (BigZr_u(Nbig, iEtaBig, iXiBig) <= MyDep)
		  test=1;
		  idxbig=CorrespMatBig_u(Nbig, iEtaBig, iXiBig);
		  nbU_v=nbU_v+1;
		  iListU_v(nbU_v,1)=SIZ_u_sma+idxSma_v;
		  jListU_v(nbU_v,1)=idxbig;
		  sListU_v(nbU_v,1)=eWeight;
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    for i=1:nbU_v
	      sListU_v(i,1)=sListU_v(i,1)/eSumWeight;
	    end;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_uv(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_uv(iEtaSma, iXiSma, idxdep);
	    idxbig=CorrespMatBig_u(iZlev, iEtaBig, iXiBig);
	    nbU_v=nbU_v+1;
	    iListU_v(nbU_v,1)=SIZ_u_sma+idxSma_v;
	    jListU_v(nbU_v,1)=idxbig;
	    sListU_v(nbU_v,1)=1;
	  end;
	  %
	  eSumWeight=0;
	  nbV_v=0;
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_vv(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_vv(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_vv(iEtaSma, iXiSma, idx);
	      Kv=find(isfinite(BigZr_v(:, iEtaBig, iXiBig)));
	      idxfind=min(Kv);
	      ListZ(idx,1)=BigZr_v(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZr_v(iNbig, iEtaBig, iXiBig);
		dep2=BigZr_v(iNbig+1, iEtaBig, iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep <= dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  idxbig1=CorrespMatBig_v(iNbig, iEtaBig, iXiBig);
		  idxbig2=CorrespMatBig_v(iNbig+1, iEtaBig, iXiBig);
		  nbV_v=nbV_v+1;
		  iListV_v(nbV_v,1)=SIZ_u_sma+idxSma_v;
		  jListV_v(nbV_v,1)=SIZ_u_big+idxbig1;
		  sListV_v(nbV_v,1)=eWeight*alpha1;
		  nbV_v=nbV_v+1;
		  iListV_v(nbV_v,1)=SIZ_u_sma+idxSma_v;
		  jListV_v(nbV_v,1)=SIZ_u_big+idxbig2;
		  sListV_v(nbV_v,1)=eWeight*alpha2;
		end;
	      end;
	      if (test == 0)
		if (BigZr_v(Nbig, iEtaBig, iXiBig) <= MyDep)
		  test=1;
		  idxbig=CorrespMatBig_v(Nbig, iEtaBig, iXiBig);
		  nbV_v=nbV_v+1;
		  iListV_v(nbV_v,1)=SIZ_u_sma+idxSma_v;
		  jListV_v(nbV_v,1)=SIZ_u_big+idxbig;
		  sListV_v(nbV_v,1)=eWeight;
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    for i=1:nbV_v
	      sListV_v(i,1)=sListV_v(i,1)/eSumWeight;
	    end;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_vv(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_vv(iEtaSma, iXiSma, idxdep);
	    idxbig=CorrespMatBig_v(iZlev, iEtaBig, iXiBig);
	    nbV_v=nbV_v+1;
	    iListV_v(nbV_v,1)=SIZ_u_sma+idxSma_v;
	    jListV_v(nbV_v,1)=SIZ_u_big+idxbig;
	    sListV_v(nbV_v,1)=1;
	  end;
	  for i=1:nbU_v
	    idxspm=idxspm+1;
	  iList(idxspm,1)=iListU_v(i,1);
	  jList(idxspm,1)=jListU_v(i,1);
	  sList(idxspm,1)=-sListU_v(i,1)*sin(deltaAng);
	  end;
	  for i=1:nbV_v
	    idxspm=idxspm+1;
	    iList(idxspm,1)=iListV_v(i,1);
	    jList(idxspm,1)=jListV_v(i,1);
	    sList(idxspm,1)=sListV_v(i,1)*cos(deltaAng);
	  end;
	end;
      end;
    end;
  end;
end;
iListRed=iList(1:idxspm,1);
jListRed=jList(1:idxspm,1);
sListRed=sList(1:idxspm,1);
SPmat=sparse(iListRed, jListRed, sListRed, SIZ_sma, SIZ_big);
ArrayBigSma3Duv.SPmat=SPmat;
ArrayBigSma3Duv.eta_u_sma=eta_u_sma;
ArrayBigSma3Duv.xi_u_sma=xi_u_sma;
ArrayBigSma3Duv.eta_v_sma=eta_v_sma;
ArrayBigSma3Duv.xi_v_sma=xi_v_sma;
ArrayBigSma3Duv.SIZ_u_sma=SIZ_u_sma;
ArrayBigSma3Duv.SIZ_v_sma=SIZ_v_sma;
ArrayBigSma3Duv.SIZ_sma=SIZ_sma;
ArrayBigSma3Duv.Nsma=Nsma;
ArrayBigSma3Duv.eta_u_big=eta_u_big;
ArrayBigSma3Duv.xi_u_big=xi_u_big;
ArrayBigSma3Duv.eta_v_big=eta_v_big;
ArrayBigSma3Duv.xi_v_big=xi_v_big;
ArrayBigSma3Duv.SIZ_u_big=SIZ_u_big;
ArrayBigSma3Duv.SIZ_v_big=SIZ_v_big;
ArrayBigSma3Duv.SIZ_big=SIZ_big;
ArrayBigSma3Duv.Nbig=Nbig;
