function nbDye=FILE_GetNbDye(HisFile)
TheAPI=GetAPItype();
if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
  nc=netcdf(HisFile, 'nowrite');
  iDye=0;
  while(1)
    iDye=iDye+1;
    DyeName=['dye_' StringNumber(iDye, 2)];
    H=nc{DyeName};
    K=size(H);
    if (K(1,1) == 0)
      break;
    end;
  end;
  close(nc);
else
  iDye=0;
  while(1)
    iDye=iDye+1;
    DyeName=['dye_' StringNumber(iDye, 2)];
    eRes=nc_isvar(HisFile, DyeName);
    if (eRes ~= 1)
      break;
    end;
  end;
end;
nbDye=iDye-1;
