function dist=GeodesicDistance_V2(LonDeg1, LatDeg1, LonDeg2, LatDeg2)
lon1=pi*LonDeg1/180;
lat1=pi*LatDeg1/180;
x1=cos(lon1)*cos(lat1);
y1=sin(lon1)*cos(lat1);
z1=sin(lat1);

lon2=pi*LonDeg2/180;
lat2=pi*LatDeg2/180;
x2=cos(lon2)*cos(lat2);
y2=sin(lon2)*cos(lat2);
z2=sin(lat2);
scalprod=x1*x2+y1*y2+z1*z2;
if (scalprod > 1)
  dist=0;
else
  dist=acos(scalprod);
end;
%dist=sqrt((x1-x2)^2+(y1-y2)^2+(z1-z2)^2);
