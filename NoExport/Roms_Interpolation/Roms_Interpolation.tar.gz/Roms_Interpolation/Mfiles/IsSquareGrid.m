function test=IsSquareGrid(LON_rho, LAT_rho)
[aSize, bSize]=size(LON_rho);
%disp(['aSize=' num2str(aSize) ' bSize=' num2str(bSize)]);
if (aSize == 1 || bSize == 1)
  test=0;
else
  test=1;
end;
