function TEMPsma=InterpolMemEff_R2R_3Dfield(...
    TotalArray, ARVDbig, ARVDsma, TEMPbig)
MSKbig_rho=TotalArray.MSKbig_rho;
MSKsma_rho=TotalArray.MSKsma_rho;
DEPbig_rho=TotalArray.DEPbig_rho;
DEPsma_rho=TotalArray.DEPsma_rho;
ListRelETA_rr=TotalArray.ListRelETA_rr;
ListRelXI_rr=TotalArray.ListRelXI_rr;
ListRelCoeff_rr=TotalArray.ListRelCoeff_rr;
%
[eta_rho_big, xi_rho_big]=size(MSKbig_rho);
[eta_rho_sma, xi_rho_sma]=size(MSKsma_rho);
%
Nbig=ARVDbig.N;
Nsma=ARVDsma.N;
%
[Nbig1, eta_rho_big1, xi_rho_big1]=size(TEMPbig);
if (eta_rho_big1 ~= eta_rho_big || xi_rho_big1 ~= xi_rho_big || ...
    Nbig1 ~= Nbig)
  disp('We have a size error between TotalArray and TEMPbig');
  error('Please correct');
end;
% the depths are negative with level 1 at the bottom, and N at the
% top level. Z_w and Z_r are intersparsed
% NaN values are allowed to deal with Z-coordinate systems
%
[BigZ_r, BigZ_w]=GetVerticalLevels2(DEPbig_rho, MSKbig_rho, ARVDbig);
[SmaZ_r, SmaZ_w]=GetVerticalLevels2(DEPsma_rho, MSKsma_rho, ARVDsma);
ListZ=zeros(4,1);
ListIDX=zeros(4,1);
%
TEMPsma=zeros(Nsma, eta_rho_sma, xi_rho_sma);
for iEtaSma=1:eta_rho_sma
  for iXiSma=1:xi_rho_sma
    if (MSKsma_rho(iEtaSma, iXiSma) == 1)
      for iNsma=1:Nsma
	eSum=0;
	eSumWeight=0;
	MyDep=SmaZ_r(iNsma, iEtaSma, iXiSma);
	if (isfinite(MyDep) == 1)
	  for idx=1:4
	    ListZ(idx,1)=0;
	    eWeight=ListRelCoeff_rr(iEtaSma, iXiSma, idx);
	    if (eWeight > 0)
	      iEtaBig=ListRelETA_rr(iEtaSma, iXiSma, idx);
	      iXiBig=ListRelXI_rr(iEtaSma, iXiSma, idx);
	      K=find(isfinite(BigZ_r(:, iEtaBig, iXiBig)));
	      idxfind=min(K);
	      ListZ(idx,1)=BigZ_r(idxfind, iEtaBig, iXiBig);
	      ListIDX(idx,1)=idxfind;
	      test=0;
	      for iNbig=1:Nbig-1
		dep1=BigZ_r(iNbig,  iEtaBig,iXiBig);
		dep2=BigZ_r(iNbig+1,iEtaBig,iXiBig);
		if (isfinite(dep1) == 1 && isfinite(dep2) == 1 ...
		    && dep1 <= MyDep && MyDep < dep2)
		  test=1;
		  alpha1=(dep2-MyDep)/(dep2-dep1);
		  alpha2=(MyDep-dep1)/(dep2-dep1);
		  eSum=eSum+eWeight*alpha1*...
		       TEMPbig(iNbig, iEtaBig, iXiBig);
		  eSum=eSum+eWeight*alpha2*...
		       TEMPbig(iNbig+1, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 0)
		if (BigZ_r(Nbig, iEtaBig, iXiBig) <= MyDep)
		  test=1;
		  eSum=eSum+eWeight*TEMPbig(Nbig, iEtaBig, iXiBig);
		end;
	      end;
	      if (test == 1)
		eSumWeight=eSumWeight+eWeight;
	      end;
	    end;
	  end;
	  if (eSumWeight > 0)
	    eTempSma=eSum/eSumWeight;
%	    if (eTempSma < 1)
%	      disp('Please debug from here, case 1 MemEff_R2R_3D');
%	      keyboard;
%	    end;
	  else
	    Kdep=find(ListZ == min(ListZ));
	    idxdep=Kdep(1,1);
	    iZlev=ListIDX(idxdep,1);
	    iEtaBig=ListRelETA_rr(iEtaSma, iXiSma, idxdep);
	    iXiBig=ListRelXI_rr(iEtaSma, iXiSma, idxdep);
	    eTempSma=TEMPbig(iZlev, iEtaBig, iXiBig);
%	    if (eTempSma < 1)
%	      disp('Please debug from here, case 2 MemEff_R2R_3D');
%	      keyboard;
%	    end;
	  end;
%	  if (eTempSma < 1)
%	    disp('Please debug from here MemEff_R2R_3D');
%	    keyboard;
%	  end;
	  TEMPsma(iNsma, iEtaSma, iXiSma)=eTempSma;
	end;
      end;
    end;
  end;
end;
