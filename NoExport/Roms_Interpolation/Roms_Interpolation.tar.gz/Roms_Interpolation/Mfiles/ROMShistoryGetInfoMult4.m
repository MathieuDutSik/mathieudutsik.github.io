function HistoryArray=ROMShistoryGetInfoMult4(...
    HisPrefix, BeginTime, EndTime)

Day2sec=24*3600;
[BeginTimeDay, BeginTimeSec]=GetCorrectTime(BeginTime);
[EndTimeDay, EndTimeSec]=GetCorrectTime(EndTime);
%disp([' BeginTimeSec=' num2str(BeginTimeSec) ...
%      ' EndTimeSec=' num2str(EndTimeSec)]);
%disp([' BeginTimeDay=' num2str(BeginTimeDay) ...
%      ' EndTimeDay=' num2str(EndTimeDay)]);

[ListTimeHistory, ListFile, ListIRecord, nbFile, ...
 ListFileUniq, ListIFileUniq]=...
    ROMShistoryGetInfoMult2(HisPrefix, BeginTimeSec, EndTimeSec);
nbTime=size(ListTimeHistory,1);
nbFileUniq=size(ListFileUniq,2);
ListIsPerfectRestart=zeros(nbTime,1);
ListTimeHistorySec=ListTimeHistory;
ListTimeHistoryDay=ListTimeHistorySec/Day2sec;
%
HistoryArray.ListTimeHistory=ListTimeHistory;
HistoryArray.ListTimeHistorySec=ListTimeHistorySec;
HistoryArray.ListTimeHistoryDay=ListTimeHistoryDay;
HistoryArray.HisPrefix=HisPrefix;
HistoryArray.ListIsPerfectRestart=ListIsPerfectRestart;
%
strPresFirst=DATE_ConvertMjd2mystringPres(min(ListTimeHistoryDay));
strPresLast=DATE_ConvertMjd2mystringPres(max(ListTimeHistoryDay));
HistoryArray.FirstHistoryTime=strPresFirst;
HistoryArray.LastHistoryTime=strPresLast;
HistoryArray.ListFile=ListFile;
HistoryArray.ListIRecord=ListIRecord;
HistoryArray.ListIFileUniq=ListIFileUniq;
HistoryArray.nbFile=nbFile;
HistoryArray.nbFileUniq=nbFileUniq;
HistoryArray.nbTime=nbTime;
HistoryArray.nbRecord=nbTime;
HistoryArray.ListFileUniq=ListFileUniq;
%
for iTime=1:nbTime
  eTimeDay=ListTimeHistoryDay(iTime,1);
  strPres=DATE_ConvertMjd2mystringPres(eTimeDay);
  ListTimeString{iTime}=strPres;
end;
HistoryArray.ListTimeString=ListTimeString;
%
if (nbTime >= 2)
  DeltaTimeSec=ListTimeHistory(2,1)-ListTimeHistory(1,1);
  DeltaTimeDay=DeltaTimeSec/Day2sec;
  nbPerDay=1/DeltaTimeDay;
  HistoryArray.DeltaTimeSec=DeltaTimeSec;
  HistoryArray.DeltaTimeDay=DeltaTimeDay;
  HistoryArray.nbPerDay=nbPerDay;
end;
%
eFile1=ListFileUniq{1};
nbDye=FILE_GetNbDye(eFile1);
TheAPI=GetAPItype();
if (UTIL_IsStringEqual(TheAPI, 'API1') == 1)
  nc=netcdf(eFile1, 'nowrite');
  s_rho=length(nc('s_rho'));
  xy_rho=length(nc('xy_rho'));
  close(nc);
  if (xy_rho == 0)
    WriteWater=0;
  else
    WriteWater=1;
  end;
else
  s_rho=nc_getdiminfo(eFile1,'s_rho','Length')
  test=nc_isdim(eFile1, 'xy_rho');
  if (test == 1)
    WriteWater=1;
  else
    WriteWater=0;
  end;
end;
s_w=s_rho+1;
ListWriteWater=WriteWater*ones(nbTime,1);
HistoryArray.ListWriteWater=ListWriteWater;
HistoryArray.WriteWater=WriteWater;
%
K=find(ListTimeHistorySec == BeginTimeSec);
if (size(K, 1) == 1)
  HasBeginInSeries=1;
else
  HasBeginInSeries=0;
end;
K=find(ListTimeHistorySec == EndTimeSec);
if (size(K, 1) == 1)
  HasEndInSeries=1;
else
  HasEndInSeries=0;
end;
HistoryArray.HasBeginInSeries=HasBeginInSeries;
HistoryArray.HasEndInSeries=HasEndInSeries;
%
HistoryArray.s_rho=s_rho;
HistoryArray.s_w=s_w;
HistoryArray.AskedBeginTimeSec=BeginTimeSec;
HistoryArray.AskedEndTimeSec=EndTimeSec;
HistoryArray.nbDye=nbDye;
HistoryArray.Nature='ROMS';
