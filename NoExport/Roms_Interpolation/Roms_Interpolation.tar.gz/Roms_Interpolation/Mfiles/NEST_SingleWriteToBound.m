function NEST_SingleWriteToBound(...
    ncBound, iTime, RecordBound, eTimeRequest, ...
    ZETAsma, TEMPsma, SALTsma, ...
    Usma, Vsma, UBARsma, VBARsma)

if (eTimeRequest < 100000)
  eTimeRequestDay=eTimeRequest;
else
  Day2sec=24*3600;
  eTimeRequestDay=eTimeRequest/Day2sec;
end;

[eta_rho_sma, xi_rho_sma]=size(ZETAsma);
[eta_u_sma, xi_u_sma]=size(UBARsma);
[eta_v_sma, xi_v_sma]=size(VBARsma);
ncBound{'zeta_time'}(iTime)=eTimeRequestDay;
ncBound{'v2d_time'}(iTime)=eTimeRequestDay;
ncBound{'v3d_time'}(iTime)=eTimeRequestDay;
ncBound{'temp_time'}(iTime)=eTimeRequestDay;
ncBound{'salt_time'}(iTime)=eTimeRequestDay;
strPres=DATE_ConvertMjd2mystringPres(eTimeRequestDay);
ncBound{'ocean_time_str'}(iTime, :)=strPres;
DoCheck=1;
if (DoCheck == 1)
  nbNaNzeta=sum(isnan(ZETAsma(:)));
  nbNaNtemp=sum(isnan(TEMPsma(:)));
  nbNaNsalt=sum(isnan(SALTsma(:)));
  nbNaNubar=sum(isnan(UBARsma(:)));
  nbNaNvbar=sum(isnan(VBARsma(:)));
  nbNaNu=sum(isnan(Usma(:)));
  nbNaNv=sum(isnan(Vsma(:)));
  if (nbNaNzeta > 0 || nbNaNtemp > 0 || ...
      nbNaNsalt > 0 || nbNaNubar > 0 || ...
      nbNaNvbar > 0 || nbNaNu > 0 || nbNaNv > 0)
    disp('Inconsistent input to the nesting output function');
    error('Please correct');
  end;
end;

if (RecordBound.DoEast == 1)
  ZETAeast=squeeze(ZETAsma(:, xi_rho_sma));
  TEMPeast=squeeze(TEMPsma(:, :, xi_rho_sma));
  SALTeast=squeeze(SALTsma(:, :, xi_rho_sma));
  UBAReast=squeeze(UBARsma(:, xi_u_sma));
  VBAReast=squeeze(VBARsma(:, xi_v_sma));
  Ueast=squeeze(Usma(:, :, xi_u_sma));
  Veast=squeeze(Vsma(:, :, xi_v_sma));
  ncBound{'zeta_east'}(iTime, :)=ZETAeast;
  ncBound{'temp_east'}(iTime, :, :)=TEMPeast;
  ncBound{'salt_east'}(iTime, :, :)=SALTeast;
  ncBound{'ubar_east'}(iTime, :)=UBAReast;
  ncBound{'vbar_east'}(iTime, :)=VBAReast;
  ncBound{'u_east'}(iTime, :, :)=Ueast;
  ncBound{'v_east'}(iTime, :, :)=Veast;
end;
if (RecordBound.DoWest == 1)
  ZETAwest=squeeze(ZETAsma(:, 1));
  TEMPwest=squeeze(TEMPsma(:, :, 1));
  SALTwest=squeeze(SALTsma(:, :, 1));
  UBARwest=squeeze(UBARsma(:, 1));
  VBARwest=squeeze(VBARsma(:, 1));
  Uwest=squeeze(Usma(:, :, 1));
  Vwest=squeeze(Vsma(:, :, 1));
  ncBound{'zeta_west'}(iTime, :)=ZETAwest;
  ncBound{'temp_west'}(iTime, :, :)=TEMPwest;
  ncBound{'salt_west'}(iTime, :, :)=SALTwest;
  ncBound{'ubar_west'}(iTime, :)=UBARwest;
  ncBound{'vbar_west'}(iTime, :)=VBARwest;
  ncBound{'u_west'}(iTime, :, :)=Uwest;
  ncBound{'v_west'}(iTime, :, :)=Vwest;
end;
if (RecordBound.DoSouth == 1)
  ZETAsouth=squeeze(ZETAsma(1, :));
  TEMPsouth=squeeze(TEMPsma(:, 1, :));
  SALTsouth=squeeze(SALTsma(:, 1, :));
  UBARsouth=squeeze(UBARsma(1, :));
  VBARsouth=squeeze(VBARsma(1, :));
  Usouth=squeeze(Usma(:, 1, :));
  Vsouth=squeeze(Vsma(:, 1, :));
  ncBound{'zeta_south'}(iTime, :)=ZETAsouth;
  ncBound{'temp_south'}(iTime, :, :)=TEMPsouth;
  ncBound{'salt_south'}(iTime, :, :)=SALTsouth;
  ncBound{'ubar_south'}(iTime, :)=UBARsouth;
  ncBound{'vbar_south'}(iTime, :)=VBARsouth;
  ncBound{'u_south'}(iTime, :, :)=Usouth;
  ncBound{'v_south'}(iTime, :, :)=Vsouth;
end;
if (RecordBound.DoNorth == 1)
  ZETAnorth=squeeze(ZETAsma(eta_rho_sma,:));
  TEMPnorth=squeeze(TEMPsma(:, eta_rho_sma,:));
  SALTnorth=squeeze(SALTsma(:, eta_rho_sma,:));
  UBARnorth=squeeze(UBARsma(eta_u_sma,:));
  VBARnorth=squeeze(VBARsma(eta_v_sma,:));
  Unorth=squeeze(Usma(:, eta_u_sma,:));
  Vnorth=squeeze(Vsma(:, eta_v_sma,:));
  ncBound{'zeta_north'}(iTime, :)=ZETAnorth;
  ncBound{'temp_north'}(iTime, :, :)=TEMPnorth;
  ncBound{'salt_north'}(iTime, :, :)=SALTnorth;
  ncBound{'ubar_north'}(iTime, :)=UBARnorth;
  ncBound{'vbar_north'}(iTime, :)=VBARnorth;
  ncBound{'u_north'}(iTime, :, :)=Unorth;
  ncBound{'v_north'}(iTime, :, :)=Vnorth;
end;
