#include <fstream>
#include <iostream>
#include <list>
#include <set>
#include <string>
#include <cstdlib>
#include <cstdio>
#include <vector>

using namespace std;


void ReadMatrix(list<vector<long> >& TheGroup, char* TheFile)
{
  ifstream* pFileStream = 0;
  long size, nbElt, iElt, i, TheVal;
  vector<long> TheElt;
  pFileStream=new ifstream(TheFile);
  (*pFileStream) >> size;
  (*pFileStream) >> nbElt;
  for (iElt=1; iElt<=nbElt; iElt++)
    {
      for (i=1; i<=size; i++)
	{
	  (*pFileStream) >> TheVal;
	  TheElt.push_back(TheVal);
	}
      TheGroup.push_back(TheElt);
      TheElt.clear();
    }
  delete pFileStream;
}


void ReadAdjacencyMatrix(vector<vector<long> >& TheAdjMat, char* TheFile, long& size)
{
  ifstream* pFileStream = 0;
  long iVert, jVert, TheVal;
  vector<long> TheLine;
  pFileStream=new ifstream(TheFile);
  (*pFileStream) >> size;
  for (iVert=1; iVert<=size; iVert++)
    {
      for (jVert=1; jVert<=size; jVert++)
	{
	  (*pFileStream) >> TheVal;
	  TheLine.push_back(TheVal);
	}
      TheAdjMat.push_back(TheLine);
      TheLine.clear();
    }
  delete pFileStream;
}


void ActionSet(set<long>& eImage, set<long>& eOrigin, vector<long>& OneElt)
{
  set<long>::iterator iter=eOrigin.begin();
  long fVal;
  eImage.clear();
  while(iter != eOrigin.end())
    {
      fVal=OneElt[*iter-1];
      eImage.insert(fVal);
      iter++;
    }
}








void ListPossibilities(vector<vector<long> >& TheAdjMat, set<long>& eSet, list<vector<long> >& TheGroup, set<long>& ListPoss, long& size)
{
  set<long>::iterator iter;
  long fVal, iVert, jVert, test1;
  vector<long> eLine;
  long iBegin;
  iter=eSet.end();
  iter--;
  iBegin=*iter+1;
  ListPoss.clear();
  for (iVert=iBegin; iVert<=size; iVert++)
    {
      eLine=TheAdjMat[iVert-1];
      test1=1;
      iter=eSet.begin();
      while(iter != eSet.end())
	{
	  fVal=*iter;
	  if (eLine[fVal-1] == 0)
	    {
	      test1=0;
	      break;
	    }
	  iter++;
	}
      if (test1 == 1)
	{
	  ListPoss.insert(iVert);
	}
    }
}


void SinglePrint(set<long>& eClique, ofstream& MyOutput)
{
  set<long>::iterator iter;
  long eVal;
  iter=eClique.begin();
  while(iter != eClique.end())
    {
      eVal=*iter;
      MyOutput << " " << eVal;
      iter++;
    }
  MyOutput << "\n";
}


int IsSmallest(set<long>& eSet, list<vector<long> >& TheGroup)
{
  list<vector<long> >::iterator iterGroup;
  vector<long> eElt;
  set<long> eImage;
  iterGroup=TheGroup.begin();
  while(iterGroup != TheGroup.end())
    {
      eElt=*iterGroup;
      ActionSet(eImage, eSet, eElt);
      if (eImage<eSet)
	{
	  return 0;
	}
      iterGroup++;
    }
  return 1;
}



void OneStepEnumeration(char* FileInput, char* FileOutput, vector<vector<long> >& TheAdjMat, list<vector<long> >& TheGroup, long& size)
{
  ifstream* pFileStream = 0;
  long sizeClique, iVert;
  long nbClique, iClique;
  long iElt;
  int test;
  set<long> ListPoss;
  set<long>::iterator iter;
  pFileStream=new ifstream(FileInput);
  (*pFileStream) >> sizeClique;
  (*pFileStream) >> nbClique;
  set<long> eClique;
  set<long> eNewClique;
  long fVal, TheVal;
  ofstream output(FileOutput);
  for (iClique=1; iClique<=nbClique; iClique++)
    {
      eClique.clear();
      for (iVert=1; iVert<=sizeClique; iVert++)
	{
	  (*pFileStream) >> TheVal;
	  eClique.insert(TheVal);
	}
      ListPossibilities(TheAdjMat, eClique, TheGroup, ListPoss, size);
      iter=ListPoss.begin();
      while(iter != ListPoss.end())
	{
	  fVal=*iter;
	  eNewClique=eClique;
	  eNewClique.insert(fVal);
	  test=IsSmallest(eNewClique, TheGroup);
	  if (test == 1)
	    {
	      SinglePrint(eNewClique, output);
	    }
	  iter++;
	}
    }
  delete pFileStream;
}


int main(int argc, char *argv[])
{
  long size;
  list<vector<long> > TheGroup;
  vector<vector<long> > TheAdjMat;
  if (argc !=5)
    {
      fprintf(stderr, "Number of arguments is = %ld\n", argc);
      fprintf(stderr, "This program is used as\n");
      fprintf(stderr, "MinimalCanonicAlgo [GROUP] [ADJACENCIES] [File1] [File2]\n");
      fprintf(stderr, "GROUP: the list of elements of the group\n");
      fprintf(stderr, "ADJACENCIES: The Adjacency matrix\n");
      fprintf(stderr, "File1: a list of cliques minimal in their orbit\n");
      fprintf(stderr, "File2(output): The list of cliques with one more element arising from File1 by canonical augmentation\n");
      return -1;
    }
  ReadMatrix(TheGroup, argv[1]);
  ReadAdjacencyMatrix(TheAdjMat, argv[2], size);
  cout << "We have read the adjacency matrix\n";
  OneStepEnumeration(argv[3], argv[4], TheAdjMat, TheGroup, size);
}
