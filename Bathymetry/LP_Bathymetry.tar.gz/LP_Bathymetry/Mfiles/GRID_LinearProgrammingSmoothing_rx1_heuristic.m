function RetBathy=GRID_LinearProgrammingSmoothing_rx1_heuristic(...
    MSK_rho, Hobs, rx1max, ARVD)
%
% RetBathy=GRID_LinearProgrammingSmoothing_rx1_heuristicSec(...
%    MSK_rho, Hobs, rx1max, ARVD)
%
% We first find a constanst multiplier factor and we find the
% corresponding rx0 factor. Then we apply in order to remove the
% last blemish the Martinho Bateen strategy of increasing the
% bathymetry.

TheFact=GRID_GetARVD_rxMult(ARVD);
disp(['rx1=' num2str(rx1max)]);
rx0max=rx1max/TheFact;
disp(['TheFact=' num2str(TheFact) '  rx0max=' num2str(rx0max)]);

TheNewBathy=GRID_LinProgHeuristic_rx0(...
    MSK_rho, Hobs, rx0max);

RetBathy=GRID_SmoothPositive_ROMS_rx1(...
    MSK_rho, TheNewBathy, rx1max, ARVD);
