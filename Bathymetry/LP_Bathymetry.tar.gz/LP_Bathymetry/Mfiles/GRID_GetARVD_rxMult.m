function TheFact=GRID_GetARVD_rxMult(ARVD)

[Sc_w, Cs_w, Sc_r, Cs_r]=GRID_GetSc_Cs_V2(ARVD);
N=ARVD.N;
TheFact=0;
for i=1:N
  eF1=(Cs_w(i+1,1) + Cs_w(i+1,1))/(Cs_w(i+1,1)-Cs_w(i,1));
  eF=abs(eF1);
  if (eF > TheFact)
    TheFact=eF;
  end;
end;
