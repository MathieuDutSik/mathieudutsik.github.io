TheChoice=1;
disp(['TheChoice=' num2str(TheChoice)]);


if (TheChoice == 1)
  iSiz=15;
  jSiz=15;
  LON_rho=zeros(iSiz, jSiz);
  LAT_rho=zeros(iSiz, jSiz);
  for i=1:iSiz
    for j=1:jSiz
      LON_rho(i, j)=i;
      LAT_rho(i, j)=j;
    end;
  end;
  MSK_rho=ones(iSiz, jSiz);
  MSK_rho(2:6, 3:6)=0;
  MSK_rho(2,6)=0;
  MSK_rho(1,6)=0;
  MSK_rho(1,5)=0;

  MSK_rho(6,7)=0;
  MSK_rho(6,8)=0;
  MSK_rho(5,8)=0;
  MSK_rho(7,8)=0;
  
  MSK_rho(7,6)=0;
  MSK_rho(8,6)=0;
  MSK_rho(8,7)=1;
  MSK_rho(8,5)=0;

  MSK_rho(9,7)=0;
  MSK_rho(10,8)=0;
  MSK_rho(10,9)=0;
  MSK_rho(11,8)=0;

  
  MSK_rho(7,9)=0;
  MSK_rho(7,10)=0;
  MSK_rho(7,11)=0;

  MSK_rho(5,9)=0;
  MSK_rho(5,10)=0;
  MSK_rho(5,11)=0;

  
  
  DEP_rho=ones(iSiz, jSiz);
end;

GrdArr=GRID_GetArrayFromLonLatMSK(...
    LON_rho, LAT_rho, MSK_rho, DEP_rho);

DoPlotGrid=1;
if (DoPlotGrid == 1)
  [eta_rho, xi_rho]=size(GrdArr.LON_rho);
  clf;
  hold on;
  DoLandMask=1;
  if (DoLandMask == 1)
    TheColorMask='b';
    for iEta=1:eta_rho
      for iXi=1:xi_rho
	if (GrdArr.MSK_rho(iEta, iXi) == 0)
	  Xli=[GrdArr.LON_psi2(iEta+1,iXi+1); GrdArr.LON_psi2(iEta+1,iXi); ...
	       GrdArr.LON_psi2(iEta,iXi); GrdArr.LON_psi2(iEta,iXi+1)];
	  Yli=[GrdArr.LAT_psi2(iEta+1,iXi+1); GrdArr.LAT_psi2(iEta+1,iXi); ...
	       GrdArr.LAT_psi2(iEta,iXi); GrdArr.LAT_psi2(iEta,iXi+1)];
	  fill(Xli, Yli, TheColorMask);
	end;
      end;
    end;
  end;
  TheColorRho='r';
  eRadRho=0.2;
  for iEta=1:eta_rho
    for iXi=1:xi_rho
      if (GrdArr.MSK_rho(iEta, iXi) == 1)
	eLon=GrdArr.LON_rho(iEta, iXi);
	eLat=GrdArr.LAT_rho(iEta, iXi);
	TD_circle4(eLon, eLat, eRadRho, TheColorRho);
      end;
    end;
  end;
  [eta_psi, xi_psi]=size(GrdArr.LON_psi);
  TheColorPsi='k';
  eRadPsi=0.12;
  for iEta=1:eta_psi
    for iXi=1:xi_psi
      if (GrdArr.MSK_psi(iEta, iXi) == 1)
	eLon=GrdArr.LON_psi(iEta, iXi);
	eLat=GrdArr.LAT_psi(iEta, iXi);
	TD_circle4(eLon, eLat, eRadPsi, TheColorPsi);
      end;
    end;
  end;
end;

TheRecord=GRID_ToTriangulation_V4(GrdArr);
nbTrig=TheRecord.nbTrig;
LS=[2,3,1];
for iTrig=1:nbTrig
  for i=1:3
    j=LS(1,i);
    iNode=TheRecord.ListTrig(iTrig,i);
    jNode=TheRecord.ListTrig(iTrig,j);
    eLon=TheRecord.ListNode(iNode,1);
    eLat=TheRecord.ListNode(iNode,2);
    fLon=TheRecord.ListNode(jNode,1);
    fLat=TheRecord.ListNode(jNode,2);
    line([eLon fLon], [eLat fLat], 'Color', 'g');
  end;
end;
