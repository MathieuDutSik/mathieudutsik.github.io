TheChoice=1;
disp(['TheChoice=' num2str(TheChoice)]);
if (TheChoice == 1)
  GridFile='Grids/ncom2_376x136_TOP7samp_simple_r0_18.nc';
else
  disp('Please put your mind here');
  error('Please correct');
end;
GrdArr=GRID_GetArraySimple(GridFile);

TheRec=GRID_ToTriangulation_V4(GrdArr);
FileName='NCOM2_AllInfo/TheDataV4.gr3';
TRIG_WriteGR3(FileName, TheRec.ListNode, ...
	      TheRec.ListTrig, TheRec.ListBathy);
FileName='NCOM2_AllInfo/systemV4.dat';
TRIG_WriteSystemDatWWM(...
    FileName, TheRec.ListTrig, ...
    TheRec.ListNode, TheRec.ListBathy);

DoPlot=1;
if (DoPlot == 1)
  TheZer=zeros(TheRec.nbNode, 1);
  ListLON=squeeze(TheRec.ListNode(:, 1));
  ListLAT=squeeze(TheRec.ListNode(:, 2));
  trimesh(TheRec.ListTrig, ListLON, ListLAT, TheZer);
  view(2);
end;
