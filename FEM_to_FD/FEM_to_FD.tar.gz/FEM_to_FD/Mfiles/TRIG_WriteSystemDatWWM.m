function TRIG_WriteSystemDatWWM(...
    FileName, ListTrig, ListNode, ListBathy)

nbNode=size(ListNode,1);
nbTrig=size(ListTrig,1);
NewListTrig=TRIG_SignOrdering(ListTrig, ListNode);


f=fopen(FileName, 'w');
fprintf(f, '%s\n', 'C system.dat, erzeugt von xf am sometime');
fprintf(f, '%s\n', 'C Anzahl der Randknoten:');
fprintf(f, '%s\n', PrintInteger(0,10));
fprintf(f, '%s\n', 'C Anzahl der Gebietsknoten:');
fprintf(f, '%s\n', PrintInteger(nbNode,10));
fprintf(f, '%s\n', 'C Koordinaten und Skalarwerte der Knoten');
fprintf(f, '%s\n', 'C --------------------------------------');
fprintf(f, '%s\n', 'C Zuerst die Randknoten  (Anzahl s.o.),');
fprintf(f, '%s\n', 'C dann die Gebietsknoten (Anzahl s.o.).');
fprintf(f, '%s\n', 'C ------------+-------------+-------------+---------------');
fprintf(f, '%s\n', 'C     Nr.     |  x-Koord.   |   y-Koord.  |   Skalarwert');
fprintf(f, '%s\n', 'C ------------+-------------+-------------+---------------');
for iNode=1:nbNode
  eLon=ListNode(iNode, 1);
  eLat=ListNode(iNode, 2);
  eDep=ListBathy(iNode,1);
  fprintf(f, '%s%15.4f%15.4f%15.5f\n', ...
	  PrintInteger(iNode-1,10), eLon, eLat, eDep);
end;
fprintf(f, '%s\n', 'C ------------------------------------------------------------');
fprintf(f, '%s\n', 'C Anzahl der Elemente:');
fprintf(f, '%s\n', PrintInteger(nbTrig,10));
fprintf(f, '%s\n', 'C Elementverzeichnis');
fprintf(f, '%s\n', 'C ------------------------------------------------------------');
fprintf(f, '%s\n', 'C    Knoten i  Knoten j  Knoten k   Kennung     Nr.');
for iTrig=1:nbTrig
  iNode1=NewListTrig(iTrig,1);
  iNode2=NewListTrig(iTrig,2);
  iNode3=NewListTrig(iTrig,3);
  fprintf(f, '%s%s%s%s%s\n', ...
	  PrintInteger(iNode1-1,10), ...
	  PrintInteger(iNode2-1,10), ...
	  PrintInteger(iNode3-1,10), ...
	  PrintInteger(0,10), ...
	  PrintInteger(iTrig-1,10));
end;
fprintf(f, '%s\n', 'C ------------------------------------------------------------');
fclose(f);
