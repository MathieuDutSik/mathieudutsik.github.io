function [MSK_u, MSK_v, MSK_psi]=uvp_mask(MSK_rho)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Copyright (c) 2000 IRD                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                 %
%   compute the mask at u,v and psi points...                     %
%                                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% modified by Mathieu Dutour Sikiric
%
[Mp,Lp]=size(MSK_rho);
M=Mp-1;
L=Lp-1;
%
MSK_v=MSK_rho(1:M,:).*MSK_rho(2:Mp,:);
MSK_u=MSK_rho(:,1:L).*MSK_rho(:,2:Lp);
MSK_psi=MSK_u(1:M,:).*MSK_u(2:Mp,:);
