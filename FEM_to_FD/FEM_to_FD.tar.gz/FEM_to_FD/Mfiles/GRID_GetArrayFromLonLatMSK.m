function GrdArr=GRID_GetArrayFromLonLatMSK(LON_rho, LAT_rho, MSK_rho, DEP_rho)


GrdArr.LON_rho=LON_rho;
GrdArr.LAT_rho=LAT_rho;
GrdArr.MSK_rho=MSK_rho;
GrdArr.DEP_rho=DEP_rho;
[MSK_u, MSK_v, MSK_psi]=uvp_mask(MSK_rho);

[Mp,Lp]=size(MSK_rho);
M=Mp-1;
L=Lp-1;
LON_v=(LON_rho(1:M,:) + LON_rho(2:Mp,:))/2;
LON_u=(LON_rho(:,1:L) + LON_rho(:,2:Lp))/2;
LON_psi=(LON_u(1:M,:) + LON_u(2:Mp,:))/2;

LAT_v=(LAT_rho(1:M,:) + LAT_rho(2:Mp,:))/2;
LAT_u=(LAT_rho(:,1:L) + LAT_rho(:,2:Lp))/2;
LAT_psi=(LAT_u(1:M,:) + LAT_u(2:Mp,:))/2;

DEP_v=(DEP_rho(1:M,:) + DEP_rho(2:Mp,:))/2;
DEP_u=(DEP_rho(:,1:L) + DEP_rho(:,2:Lp))/2;
DEP_psi=(DEP_u(1:M,:) + DEP_u(2:Mp,:))/2;

GrdArr.LON_u=LON_u;
GrdArr.LAT_u=LAT_u;
GrdArr.MSK_u=MSK_u;
GrdArr.DEP_u=DEP_u;

GrdArr.LON_v=LON_v;
GrdArr.LAT_v=LAT_v;
GrdArr.MSK_v=MSK_v;
GrdArr.DEP_v=DEP_v;

GrdArr.LON_psi=LON_psi;
GrdArr.LAT_psi=LAT_psi;
GrdArr.MSK_psi=MSK_psi;
GrdArr.DEP_psi=DEP_psi;

[LON_psi2, LAT_psi2, MSK_psi2, DEP_psi2]=GRID_ExtendedPsiThi(...
    MSK_rho, LON_rho, LAT_rho, LON_psi, LAT_psi, ...
    LON_u, LAT_u, LON_v, LAT_v, ...
    DEP_rho, DEP_u, DEP_v, DEP_psi);
GrdArr.LON_psi2=LON_psi2;
GrdArr.LAT_psi2=LAT_psi2;
GrdArr.MSK_psi2=MSK_psi2;
GrdArr.DEP_psi2=DEP_psi2;
