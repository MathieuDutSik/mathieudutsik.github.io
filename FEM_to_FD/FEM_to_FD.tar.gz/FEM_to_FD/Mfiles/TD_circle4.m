function h = TD_circle4(x,y,r, eColor)
% this function draw a circle
% found on http://www.mathworks.com
d = r*2;
px = x-r;
py = y-r;
h = rectangle('Position',[px py d d],...
	      'Curvature',[1,1], ...
	      'FaceColor', eColor);
daspect([1,1,1]);
