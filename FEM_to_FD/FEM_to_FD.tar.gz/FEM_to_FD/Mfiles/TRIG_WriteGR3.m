function TRIG_WriteGR3(FileName, ListNode, ListTrig, ListBathy)
nbTrig=size(ListTrig,1);
nbVert=size(ListNode,1);

fid=fopen(FileName,'w');
fprintf(fid,'%s\n', FileName);
str=[num2str(nbTrig) ' ' num2str(nbVert)];
fprintf(fid,'%s\n', str);
for iVert=1:nbVert
  lon=ListNode(iVert,1);
  lat=ListNode(iVert,2);
  dep=ListBathy(iVert,1);
  str=[num2str(iVert) ' ' num2str(lon) ' ' num2str(lat) ' ' num2str(dep)];
  fprintf(fid,'%s\n', str);
end;

for iTrig=1:nbTrig
  iV=ListTrig(iTrig,1);
  jV=ListTrig(iTrig,2);
  kV=ListTrig(iTrig,3);
  str=[num2str(iTrig) ' 3 ' num2str(iV) ' ' num2str(jV) ...
       ' ' num2str(kV)];
  fprintf(fid,'%s\n', str);
end;
fclose(fid);


