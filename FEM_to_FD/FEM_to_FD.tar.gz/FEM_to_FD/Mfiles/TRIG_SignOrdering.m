function NewListTrig=TRIG_SignOrdering(ListTrig, ListNode)


nbTrig=size(ListTrig,1);
NewListTrig=zeros(nbTrig,3);

TheMat=zeros(3,3);

ListLon=ListNode(:, 1);
ListLat=ListNode(:, 2);

ListLonRad=ListLon*(pi/180);
ListLatRad=ListLat*(pi/180);
xList=cos(ListLonRad).*cos(ListLatRad);
yList=sin(ListLonRad).*cos(ListLatRad);
zList=sin(ListLatRad);

nbSignP=0;
nbSignM=0;
for iTrig=1:nbTrig
  iNode1=ListTrig(iTrig,1);
  iNode2=ListTrig(iTrig,2);
  iNode3=ListTrig(iTrig,3);
  TheMat(:, 1)=[xList(iNode1,1) xList(iNode2,1) xList(iNode3,1)];
  TheMat(:, 2)=[yList(iNode1,1) yList(iNode2,1) yList(iNode3,1)];
  TheMat(:, 3)=[zList(iNode1,1) zList(iNode2,1) zList(iNode3,1)];
  TheDet=det(TheMat);
  if (TheDet > 0)
    NewListTrig(iTrig, :)=ListTrig(iTrig,:);
    nbSignP=nbSignP + 1;
  else
    NewListTrig(iTrig,1)=iNode1;
    NewListTrig(iTrig,2)=iNode3;
    NewListTrig(iTrig,3)=iNode2;
    nbSignM=nbSignM+1;
  end;
end;
disp(['nbSignP=' num2str(nbSignP) '  nbSignM=' num2str(nbSignM)]);
